import express, { Request, Response } from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "25mb" }));

// Server-side Gemini client helper
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// Health check endpoint
app.get("/api/health", (_req: Request, res: Response) => {
  res.json({
    status: "ok",
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    time: new Date().toISOString(),
  });
});

// Parse timetable endpoint
app.post("/api/timetable/parse", async (req: Request, res: Response) => {
  try {
    const { timetableText, fileBase64, mimeType, academicField } = req.body;
    const ai = getGeminiClient();

    if (ai && (timetableText || fileBase64)) {
      const prompt = `You are an expert academic counselor and exam timetable parser.
Analyze this exam timetable for student in field: "${academicField || "All Fields"}".
Extract all exams into a valid JSON array of objects with the following schema:
[
  {
    "id": "unique-slug-id",
    "subject": "Name of Subject (e.g. Data Structures & Algorithms, Human Anatomy, Physics, Mathematics)",
    "code": "Course Code (e.g. CS201, ANAT101, or empty)",
    "field": "School / Intermediate / B.Tech / Medical / CA / General",
    "date": "YYYY-MM-DD format (if specific year missing, use 2026)",
    "time": "e.g. 09:30 AM - 12:30 PM",
    "durationHours": 3,
    "syllabusTopics": ["Topic 1", "Topic 2", "Topic 3", "Topic 4"],
    "priority": "High" | "Medium" | "Low",
    "recommendedStudyHours": 18,
    "status": "Upcoming"
  }
]
Return ONLY a valid JSON array, no markdown fences or other text.`;

      let responseText = "";

      if (fileBase64 && mimeType) {
        const response = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: {
            parts: [
              {
                inlineData: {
                  mimeType,
                  data: fileBase64,
                },
              },
              { text: `${prompt}\nAdditional notes/text: ${timetableText || ""}` },
            ],
          },
          config: {
            responseMimeType: "application/json",
          },
        });
        responseText = response.text || "";
      } else {
        const response = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: `${prompt}\nTimetable content:\n${timetableText}`,
          config: {
            responseMimeType: "application/json",
          },
        });
        responseText = response.text || "";
      }

      try {
        const parsed = JSON.parse(responseText);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return res.json({ exams: parsed, source: "gemini" });
        }
      } catch (parseErr) {
        console.warn("JSON parse error from Gemini timetable response, using fallback parse", parseErr);
      }
    }

    // Fallback parser if no AI key or unparseable format
    const lines = (timetableText || "").split("\n").filter((l: string) => l.trim().length > 0);
    const mockExams = lines.map((line: string, index: number) => {
      const parts = line.split(/[-–,;]/).map((p: string) => p.trim());
      const subject = parts[0] || `Exam Subject ${index + 1}`;
      const today = new Date();
      const examDate = new Date(today.getTime() + (index + 2) * 24 * 60 * 60 * 1000);
      return {
        id: `exam-${Date.now()}-${index}`,
        subject: subject,
        code: `SUB-${index + 101}`,
        field: academicField || "General",
        date: examDate.toISOString().split("T")[0],
        time: "10:00 AM - 01:00 PM",
        durationHours: 3,
        syllabusTopics: ["Key Concepts", "Core Theories", "Problem Solving", "Previous Year Questions"],
        priority: index === 0 ? "High" : "Medium",
        recommendedStudyHours: 15,
        status: "Upcoming",
      };
    });

    return res.json({
      exams: mockExams.length > 0 ? mockExams : [
        {
          id: `exam-${Date.now()}-1`,
          subject: "Mathematics & Analytical Reasoning",
          code: "MATH-101",
          field: academicField || "School / College",
          date: new Date(Date.now() + 3 * 86400000).toISOString().split("T")[0],
          time: "09:30 AM - 12:30 PM",
          durationHours: 3,
          syllabusTopics: ["Calculus & Limits", "Probability", "Linear Algebra", "Vector Calculus"],
          priority: "High",
          recommendedStudyHours: 20,
          status: "Upcoming",
        },
      ],
      source: "fallback",
    });
  } catch (error: any) {
    console.error("Error parsing timetable:", error);
    res.status(500).json({ error: error.message || "Failed to parse timetable" });
  }
});

// AI Study Assistant Chat endpoint
app.post("/api/study/chat", async (req: Request, res: Response) => {
  try {
    const { message, history = [], academicField = "General", subject = "General", topic = "General" } = req.body;
    const ai = getGeminiClient();

    if (!message) {
      return res.status(400).json({ error: "Message is required" });
    }

    if (!ai) {
      // Local comprehensive academic fallback
      return res.json({
        reply: `Here is a study breakdown for **${subject}** (${topic}):\n\n` +
          `1. **Core Concept**: Focus on high-weightage definitions and underlying principles first.\n` +
          `2. **Key Formula/Fact**: Break the problem down into fundamental steps rather than memorizing raw answers.\n` +
          `3. **Memory Mnemonic**: Group concepts into logical triads.\n` +
          `4. **Exam Tip**: In your exam answers, use labeled diagrams and underline key technical terms.\n\n` +
          `Ready to test your mastery? Start a 5-question quick quiz to unlock 15-30 minutes of earned screen time!`,
      });
    }

    const systemInstruction = `You are "Socrates-AI", a world-class academic tutor built specifically for students preparing for high-stakes examinations across all fields: School (CBSE/ICSE/State 10th-12th), Intermediate (MPC, BiPC, CEC), B.Tech Engineering (Computer Science, ECE, Mechanical, Civil), Medical (MBBS, NEET PG), Commerce/Chartered Accountancy, and competitive exams.
Student Context:
- Academic Discipline: ${academicField}
- Subject: ${subject}
- Focus Topic: ${topic}

Your goals:
1. Provide crystal-clear, intuitive explanations with analogies when helpful.
2. Provide step-by-step problem-solving breakdowns, mnemonics, or bulleted cheat-sheet summaries.
3. Keep responses structured, encouraging, and focused on exam scoring criteria.
4. Always conclude with a quick check question or invitation to test their understanding via a quiz.`;

    const formattedContents = [
      ...history.map((h: any) => ({
        role: h.role === "assistant" || h.role === "model" ? "model" : "user",
        parts: [{ text: h.text }],
      })),
      {
        role: "user",
        parts: [{ text: message }],
      },
    ];

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: formattedContents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({ reply: response.text || "I am ready to help you with your next exam question!" });
  } catch (error: any) {
    console.error("Error in study chat:", error);
    res.status(500).json({
      error: error.message || "Failed to get AI study response",
      fallback: "Focus on understanding core fundamentals and key definitions before practicing mock questions.",
    });
  }
});

// Quiz generation endpoint with adaptive performance targeting
app.post("/api/quiz/generate", async (req: Request, res: Response) => {
  try {
    const {
      academicField = "General",
      subject = "Computer Science",
      topic = "Data Structures",
      questionCount = 5,
      difficulty = "Medium",
      weakTopics = [],
      masteredTopics = [],
      pastScores = [],
      adaptationReason = "",
    } = req.body;

    const ai = getGeminiClient();

    if (ai) {
      const prompt = `You are an adaptive examination generator for high-stakes tests.
Generate exactly ${questionCount} multiple-choice questions for:
- Academic Discipline: ${academicField}
- Subject: ${subject}
- Focus Topic: ${topic}
- Target Difficulty: ${difficulty} (Options: Easy, Medium, Hard, Exam Mock)

STUDENT PERFORMANCE PROFILE & ADAPTIVE RULES:
- Student's known weak topics in this subject: ${weakTopics.length > 0 ? weakTopics.join(", ") : "None reported yet"}
- Student's mastered topics: ${masteredTopics.length > 0 ? masteredTopics.join(", ") : "None reported yet"}
- Recent quiz average: ${pastScores.length > 0 ? Math.round(pastScores.reduce((a: number, b: number) => a + b, 0) / pastScores.length) + "%" : "New student"}
- Adaptation Directive: ${adaptationReason || "Calibrate question depth and diagnostic feedback to push student toward 80%+ mastery"}

INSTRUCTIONS:
1. If the student has struggled previously with this topic, include diagnostic questions that isolate fundamental misconceptions, with exceptionally thorough explanations and memory mnemonics.
2. If the student has mastered basics (difficulty 'Hard' or 'Exam Mock'), include multi-concept synthesis questions, boundary edge cases, and time-pressured scenario questions typical of competitive entrance exams.
3. Every question must have 4 distinct options, exactly 1 correct index (0-3), a clear hint, and a pedagogical explanation.

Return ONLY a valid JSON array of objects conforming to this schema:
[
  {
    "id": 1,
    "question": "Question text...",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correctIndex": 0,
    "explanation": "Detailed explanation of why this option is correct and why other choices are wrong.",
    "hint": "Pedagogical clue."
  }
]`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.6,
        },
      });

      try {
        const questions = JSON.parse(response.text || "[]");
        if (Array.isArray(questions) && questions.length > 0) {
          return res.json({
            questions,
            source: "gemini",
            adapted: true,
            difficulty,
            adaptationReason: adaptationReason || `Customized for ${difficulty} difficulty in ${topic}`,
          });
        }
      } catch (err) {
        console.warn("Error parsing quiz JSON from Gemini, fallback will be used", err);
      }
    }

    // Comprehensive discipline-tailored fallback questions
    const fallbackQuestions = [
      {
        id: 1,
        question: `What is a fundamental principle in ${topic} within ${subject}?`,
        options: [
          "Optimizing asymptotic complexity and structured modularity",
          "Randomly guessing without empirical validation",
          "Omitting boundary case checks and constraints",
          "Increasing redundant memory allocations indefinitely",
        ],
        correctIndex: 0,
        explanation:
          "In academic examination standards, foundational principles require algorithmic efficiency, constraint validation, and clean abstraction.",
        hint: "Look for the option highlighting efficiency and structured logic.",
      },
      {
        id: 2,
        question: `When analyzing problem domains in ${subject}, what is the most critical first step?`,
        options: [
          "Jumping straight to execution without reading parameters",
          "Carefully defining constraints, inputs, and expected invariants",
          "Assuming all edge cases will resolve automatically",
          "Skipping unit verification",
        ],
        correctIndex: 1,
        explanation:
          "Defining constraints and invariants upfront prevents subtle bugs and ensures mathematically sound formulations.",
        hint: "Exam questions reward systematic specification before computation.",
      },
      {
        id: 3,
        question: `Which approach is proven to yield the highest recall efficiency during exam preparation for ${topic}?`,
        options: [
          "Passive re-reading of notes without self-testing",
          "Active recall, spaced repetition, and solving past exam papers",
          "Cramming exclusively 10 minutes before the test",
          "Multitasking on social media while reading",
        ],
        correctIndex: 1,
        explanation:
          "Cognitive science strongly establishes that active retrieval practice and spaced testing solidify long-term semantic neural pathways.",
        hint: "Active engagement outscores passive scanning.",
      },
      {
        id: 4,
        question: `In standard examination questions regarding ${topic}, what causes the most frequent loss of marks?`,
        options: [
          "Misreading the question prompt or overlooking boundary units",
          "Writing too clearly with organized headings",
          "Showing every intermediate working step",
          "Double-checking calculations",
        ],
        correctIndex: 0,
        explanation:
          "Examiners cite misinterpreting prompt constraints and neglecting dimension/unit conversion as the leading source of avoidable deductions.",
        hint: "Pay attention to question details and boundary edge cases.",
      },
      {
        id: 5,
        question: `How does continuous mastery assessment impact retention in ${subject}?`,
        options: [
          "It guarantees 0% transfer of learned concepts",
          "It reinforces neural pathways through the testing effect (positive reinforcement)",
          "It decreases focus and creates mental fatigue only",
          "It has no measurable correlation with test performance",
        ],
        correctIndex: 1,
        explanation:
          "The 'Testing Effect' proves that self-quizzing produces superior retention and builds examination composure.",
        hint: "Positive reinforcement and testing reinforce learning.",
      },
    ];

    res.json({
      questions: fallbackQuestions,
      source: "fallback",
      adapted: true,
      difficulty,
      adaptationReason: `Fallback tailored questions for ${subject} (${difficulty})`,
    });
  } catch (error: any) {
    console.error("Error generating quiz:", error);
    res.status(500).json({ error: error.message || "Failed to generate quiz" });
  }
});

// Personalized Study Plan generation endpoint based on Timetable, Subjects, and Performance
app.post("/api/study/plan", async (req: Request, res: Response) => {
  try {
    const {
      academicField = "General",
      exams = [],
      performanceProfile = { weakTopics: [], masteredTopics: [], averageScore: 75 },
      dailyHours = 4,
    } = req.body;

    const ai = getGeminiClient();

    if (ai && exams.length > 0) {
      const prompt = `You are Socrates-AI, an elite academic strategist and cognitive science study planner.
Generate a comprehensive, personalized study plan for a student.

STUDENT PROFILE:
- Academic Discipline: ${academicField}
- Upcoming Exams Schedule:
${JSON.stringify(exams.map((e: any) => ({ subject: e.subject, date: e.date, priority: e.priority, topics: e.syllabusTopics })), null, 2)}
- Current Performance in Quizzes:
  * Weak Topics (Scores <70%): ${performanceProfile.weakTopics && performanceProfile.weakTopics.length > 0 ? performanceProfile.weakTopics.join(", ") : "None reported - initial evaluation"}
  * Mastered Topics (Scores >=80%): ${performanceProfile.masteredTopics && performanceProfile.masteredTopics.length > 0 ? performanceProfile.masteredTopics.join(", ") : "None reported yet"}
  * Overall Quiz Score Average: ${performanceProfile.averageScore || 70}%
- Daily Study Target: ${dailyHours} hours

PLANNING DIRECTIVES:
1. Prioritize upcoming exams by closest exam date and priority level ('High' exams first).
2. Schedule specific slots dedicated to remediating the student's WEAK topics with active recall and targeted practice quizzes.
3. For mastered topics, schedule high-speed spaced repetition review instead of prolonged reading.
4. Structure the plan into 5-7 distinct days. For each day, include 3 to 4 concrete study tasks with realistic times (e.g., "07:00 AM", "09:30 AM", "02:00 PM", "06:30 PM", "08:30 PM").
5. Each task must specify type ('concept_review', 'practice_quiz', 'formula_drill', or 'past_paper') and duration in minutes (30 to 90 mins).

Return ONLY a valid JSON object strictly matching this schema:
{
  "id": "plan-timestamp",
  "academicField": "${academicField}",
  "summary": "Concise executive overview of strategy, highlighting exam urgency and weak topic recovery focus.",
  "examCount": ${exams.length},
  "weakTopicsCount": ${performanceProfile.weakTopics ? performanceProfile.weakTopics.length : 0},
  "days": [
    {
      "date": "YYYY-MM-DD",
      "dayName": "Monday",
      "theme": "Core Fundamentals & Weak Topic Remediation",
      "tasks": [
        {
          "id": "task-1",
          "title": "Task title",
          "subject": "Subject Name",
          "topic": "Topic Name",
          "timeSlot": "07:00 AM",
          "durationMinutes": 60,
          "type": "concept_review",
          "completed": false,
          "priority": "High",
          "reasonForInclusion": "Why this task is scheduled (e.g. Exam in 3 days / Addressing weak score in DP)"
        }
      ]
    }
  ],
  "aiNotes": [
    "Tip 1 on spaced repetition",
    "Tip 2 on exam technique",
    "Tip 3 on maintaining screen-time discipline"
  ]
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.6,
        },
      });

      try {
        const parsed = JSON.parse(response.text || "{}");
        if (parsed.days && Array.isArray(parsed.days) && parsed.days.length > 0) {
          return res.json({
            plan: {
              ...parsed,
              id: `plan-${Date.now()}`,
              generatedAt: new Date().toISOString(),
            },
            source: "gemini",
          });
        }
      } catch (e) {
        console.warn("Failed to parse AI study plan JSON, generating structured algorithmic fallback", e);
      }
    }

    // High-fidelity fallback personalized study plan
    const today = new Date();
    const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const planDays = [];

    const subjectsList = exams.length > 0 ? exams : [
      {
        subject: "Mathematics & Analytical Problem Solving",
        date: new Date(today.getTime() + 3 * 86400000).toISOString().split("T")[0],
        priority: "High",
        syllabusTopics: ["Calculus", "Probability & Matrices", "Coordinate Geometry"],
      },
      {
        subject: "Physics & Core Systems",
        date: new Date(today.getTime() + 6 * 86400000).toISOString().split("T")[0],
        priority: "High",
        syllabusTopics: ["Electrodynamics", "Thermodynamics", "Wave Optics"],
      },
    ];

    const weakList = performanceProfile.weakTopics && performanceProfile.weakTopics.length > 0
      ? performanceProfile.weakTopics
      : ["High-Yield Problem Solving", "Time Management under Exam Pressure"];

    for (let i = 0; i < 5; i++) {
      const targetDate = new Date(today.getTime() + i * 86400000);
      const dateStr = targetDate.toISOString().split("T")[0];
      const examForDay = subjectsList[i % subjectsList.length];
      const weakTopicForDay = weakList[i % weakList.length];

      planDays.push({
        date: dateStr,
        dayName: dayNames[targetDate.getDay()],
        theme: i === 0 ? "Diagnostic Assessment & Weakness Deep-Dive" : `Intensive Focus: ${examForDay.subject}`,
        tasks: [
          {
            id: `task-${i}-1`,
            title: `Active Recall & Revision: ${examForDay.subject}`,
            subject: examForDay.subject,
            topic: examForDay.syllabusTopics?.[0] || "Key Formulas & Proofs",
            timeSlot: "07:00 AM - 08:30 AM",
            durationMinutes: 90,
            type: "concept_review" as const,
            completed: false,
            priority: "High" as const,
            reasonForInclusion: `High-priority exam preparation. Scheduled during morning peak alertness.`,
          },
          {
            id: `task-${i}-2`,
            title: `Targeted Remediation Drill: ${weakTopicForDay}`,
            subject: examForDay.subject,
            topic: weakTopicForDay,
            timeSlot: "10:30 AM - 12:00 PM",
            durationMinutes: 90,
            type: "formula_drill" as const,
            completed: false,
            priority: "High" as const,
            reasonForInclusion: `Targeted based on quiz performance gap (<70% mastery).`,
          },
          {
            id: `task-${i}-3`,
            title: `Timed Mastery Quiz & Screen Time Reward Run`,
            subject: examForDay.subject,
            topic: examForDay.syllabusTopics?.[1] || "Core Mock Questions",
            timeSlot: "03:00 PM - 03:45 PM",
            durationMinutes: 45,
            type: "practice_quiz" as const,
            completed: false,
            priority: "Medium" as const,
            reasonForInclusion: `Score 80%+ to unlock 15-30 mins of authorized entertainment screen time!`,
          },
          {
            id: `task-${i}-4`,
            title: `Past Exam Paper Simulation & Mistake Log Review`,
            subject: examForDay.subject,
            topic: "Previous Year Questions & Error Log",
            timeSlot: "07:30 PM - 09:00 PM",
            durationMinutes: 90,
            type: "past_paper" as const,
            completed: false,
            priority: "High" as const,
            reasonForInclusion: `Simulate real exam timing and eliminate recurring calculation mistakes.`,
          },
        ],
      });
    }

    const plan = {
      id: `plan-${Date.now()}`,
      generatedAt: new Date().toISOString(),
      academicField,
      summary: `Personalized ${planDays.length}-Day Plan calibrated for ${subjectsList.length} upcoming exams. Focuses heavily on active retrieval and targeted drills for ${weakList.length} flagged weakness areas.`,
      examCount: subjectsList.length,
      weakTopicsCount: weakList.length,
      days: planDays,
      aiNotes: [
        "First 90 minutes of your morning are prime cognitive bandwidth: use them for hardest derivations.",
        "Take a topic quiz right after each study block: testing yourself triggers the memory consolidation effect.",
        "Maintain strict lockout: avoid opening social media until earning a verified passing score (80%+).",
      ],
    };

    res.json({ plan, source: "algorithmic" });
  } catch (error: any) {
    console.error("Error generating study plan:", error);
    res.status(500).json({ error: error.message || "Failed to generate study plan" });
  }
});


// Production and Development server setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Exam Focus Server is ready:`);
    console.log(`  ➜ Local:   http://localhost:${PORT}/`);
    console.log(`  ➜ Network: http://127.0.0.1:${PORT}/`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
