export type AcademicField =
  | 'School (Class 9-10)'
  | 'Intermediate (+2 / Junior College)'
  | 'B.Tech / Engineering'
  | 'Medical / MBBS'
  | 'Commerce & CA'
  | 'General & Competitive Exams';

export type ActiveNavTab =
  | 'dashboard'
  | 'study-plan'
  | 'timetable'
  | 'tutor'
  | 'quiz'
  | 'apps'
  | 'leaderboard';

export interface ExamItem {
  id: string;
  subject: string;
  code: string;
  field: AcademicField;
  date: string; // YYYY-MM-DD
  time: string;
  durationHours: number;
  syllabusTopics: string[];
  priority: 'High' | 'Medium' | 'Low';
  recommendedStudyHours: number;
  status: 'Upcoming' | 'In Progress' | 'Completed';
}

export interface DistractingApp {
  id: string;
  name: string;
  category: 'Social Media' | 'Video & Streaming' | 'Gaming' | 'Messaging';
  icon: string;
  accountLinked: boolean;
  blocked: boolean;
  packageUrl: string;
  dailyUsageMinutes: number;
  color: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  hint: string;
}

export interface QuizResult {
  id: string;
  examId?: string;
  subject: string;
  topic: string;
  totalQuestions: number;
  correctAnswers: number;
  percentage: number;
  earnedScreenTimeMinutes: number;
  timestamp: string;
  abandoned: boolean;
}

export interface ScreenTimePass {
  active: boolean;
  totalMinutes: number;
  remainingSeconds: number;
  unlockedAt: number | null;
  expiresAt: number | null;
  sourceQuizSubject: string;
}

export interface PenaltyState {
  active: boolean;
  reason: string;
  startedAt: number;
  durationSeconds: number; // 30 minutes = 1800 seconds
  remainingSeconds: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  topic?: string;
}

export interface UserProgress {
  xp: number;
  level: number;
  currentStreak: number;
  totalStudyMinutes: number;
  quizzesCompleted: number;
  rewardsUnlocked: number;
  penaltyCount: number;
}

export interface TopicMasteryRecord {
  subject: string;
  topic: string;
  attemptsCount?: number;
  attempts?: number;
  bestScore?: number;
  lastScore: number;
  averageScore?: number;
  masteryLevel?: 'Needs Revision' | 'Developing' | 'Mastered';
  lastAttemptDate?: string;
}

export interface StudentPerformanceProfile {
  totalQuizzes: number;
  totalQuizzesTaken?: number;
  averageScore: number;
  masteredTopics: string[];
  weakTopics: string[];
  recommendedDifficulty: 'Medium' | 'Hard' | 'Exam Mock';
  topicRecords: Record<string, TopicMasteryRecord>;
}

export interface StudyTask {
  id: string;
  title: string;
  subject: string;
  topic: string;
  timeSlot: string; // e.g. "07:00 AM"
  durationMinutes: number;
  type: 'concept_review' | 'practice_quiz' | 'formula_drill' | 'past_paper';
  completed: boolean;
  priority: 'High' | 'Medium' | 'Low';
  reasonForInclusion?: string; // e.g. "Triggered by <60% score on Dynamic Programming"
}

export interface StudyPlanDay {
  date: string;
  dayName?: string;
  dayNumber?: number;
  theme?: string;
  focusGoal?: string;
  tasks: StudyTask[];
}

export interface PersonalizedStudyPlan {
  id: string;
  title?: string;
  generatedAt: string;
  academicField?: AcademicField;
  studentField?: string;
  summary?: string;
  strategySummary?: string;
  totalDays?: number;
  examCount?: number;
  weakTopicsCount?: number;
  weakTopicsTargeted?: string[];
  days: StudyPlanDay[];
  aiNotes?: string[];
}

export interface BadgeItem {
  id: string;
  title: string;
  description: string;
  category: 'Streak' | 'Accuracy' | 'Focus' | 'Mastery';
  icon: string;
  xpReward: number;
  unlocked: boolean;
  unlockedAt?: string;
  progressText: string;
  isSecret?: boolean;
}

export interface LeaderboardEntry {
  rank: number;
  id: string;
  name: string;
  academicField: string;
  xp: number;
  streak: number;
  quizzesPassed: number;
  avatarBg: string;
  isCurrentUser?: boolean;
}

export interface RecentlyStudiedItem {
  id: string;
  courseName: string;
  topic: string;
  startTime: string;
  endTime: string;
  totalTimeSpent: string;
  date: string;
  xpEarned: number;
}
