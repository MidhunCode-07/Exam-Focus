import studyFutureGoalsImg from './study_future_goals_1789872108076.jpg';
import deepFocusNightImg from './deep_focus_night_1789872122023.jpg';
import gradLightbulbLadderImg from './grad_lightbulb_ladder_1789872136657.jpg';

export {
  studyFutureGoalsImg,
  deepFocusNightImg,
  gradLightbulbLadderImg,
};
