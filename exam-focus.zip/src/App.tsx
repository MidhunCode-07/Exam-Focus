import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { AIStudyPlanView } from './components/AIStudyPlanView';
import { TimetableUploader } from './components/TimetableUploader';
import { DistractionBlocker } from './components/DistractionBlocker';
import { AIStudyTutor } from './components/AIStudyTutor';
import { QuizModule } from './components/QuizModule';
import { LeaderboardAndBadges } from './components/LeaderboardAndBadges';
import { SimulatedAppModal } from './components/SimulatedAppModal';
import { PenaltyBanner } from './components/PenaltyBanner';
import {
  AcademicField,
  ActiveNavTab,
  ExamItem,
  DistractingApp,
  ScreenTimePass,
  PenaltyState,
  UserProgress,
  StudentPerformanceProfile,
  PersonalizedStudyPlan,
  BadgeItem,
  LeaderboardEntry,
  RecentlyStudiedItem,
} from './types';
import {
  DEFAULT_DISTRACTING_APPS,
  PRESET_TIMETABLES,
  INITIAL_BADGES,
  INITIAL_LEADERBOARD,
  INITIAL_RECENT_STUDIES,
} from './data/mockData';

export default function App() {
  // 1. Current Academic Field (School, Intermediate, B.Tech, Medical, etc.)
  const [currentField, setCurrentField] = useState<AcademicField>(() => {
    const saved = localStorage.getItem('examfocus_field');
    return (saved as AcademicField) || 'B.Tech / Engineering';
  });

  // 2. Active Scheduled Exams
  const [exams, setExams] = useState<ExamItem[]>(() => {
    const saved = localStorage.getItem(`examfocus_exams_${currentField}`);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return PRESET_TIMETABLES[currentField] || PRESET_TIMETABLES['B.Tech / Engineering'];
  });

  // 3. Linked Distracting Apps
  const [apps, setApps] = useState<DistractingApp[]>(() => {
    const saved = localStorage.getItem('examfocus_apps');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return DEFAULT_DISTRACTING_APPS;
  });

  // 4. Focus Shield Toggle
  const [focusModeEnabled, setFocusModeEnabled] = useState<boolean>(true);

  // 5. Active Tab (Dashboard, Study Plan, Timetable, Tutor, Quiz, Blocker, Leaderboard)
  const [activeTab, setActiveTab] = useState<ActiveNavTab>('dashboard');

  // 6. Selected context for study / quiz
  const [selectedExamForStudy, setSelectedExamForStudy] = useState<ExamItem | null>(null);
  const [selectedTopicForStudy, setSelectedTopicForStudy] = useState<string>('');

  // 7. Active Quiz Flag (CRITICAL: Chatbot disabled during quiz, leaving triggers 30-min penalty)
  const [isQuizActive, setIsQuizActive] = useState<boolean>(false);

  // 8. Screen Time Pass (Earned via Quiz score >= 80%)
  const [screenTimePass, setScreenTimePass] = useState<ScreenTimePass>(() => {
    const saved = localStorage.getItem('examfocus_pass');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.expiresAt && parsed.expiresAt > Date.now()) {
          const remainingSeconds = Math.max(0, Math.floor((parsed.expiresAt - Date.now()) / 1000));
          return { ...parsed, remainingSeconds, active: remainingSeconds > 0 };
        }
      } catch (e) {
        // fallback
      }
    }
    return {
      active: false,
      totalMinutes: 0,
      remainingSeconds: 0,
      unlockedAt: null,
      expiresAt: null,
      sourceQuizSubject: '',
    };
  });

  // 9. 30-Minute Penalty State (Strict penalty for abandoning an active quiz)
  const [penaltyState, setPenaltyState] = useState<PenaltyState>(() => {
    const saved = localStorage.getItem('examfocus_penalty');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const elapsed = Math.floor((Date.now() - parsed.startedAt) / 1000);
        const remaining = Math.max(0, (parsed.durationSeconds || 1800) - elapsed);
        if (remaining > 0) {
          return { ...parsed, remainingSeconds: remaining, active: true };
        }
      } catch (e) {
        // fallback
      }
    }
    return {
      active: false,
      reason: '',
      startedAt: 0,
      durationSeconds: 1800, // 30 minutes
      remainingSeconds: 0,
    };
  });

  // 10. Gamification Progress
  const [userProgress, setUserProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem('examfocus_progress');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return {
      xp: 2750,
      level: 4,
      currentStreak: 6,
      totalStudyMinutes: 280,
      quizzesCompleted: 18,
      rewardsUnlocked: 12,
      penaltyCount: 0,
    };
  });

  // 11. Student Performance Profile for Adaptive Quiz & Personalized Study Plans
  const [performanceProfile, setPerformanceProfile] = useState<StudentPerformanceProfile>(() => {
    const saved = localStorage.getItem('examfocus_perf_profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return {
      totalQuizzes: 18,
      totalQuizzesTaken: 18,
      averageScore: 78,
      recommendedDifficulty: 'Medium',
      weakTopics: ['Dynamic Programming', 'Binary Search Trees & AVL'],
      masteredTopics: ['Graph Algorithms (Dijkstra, BFS, DFS)', 'Hashing & Time Complexity'],
      topicRecords: {
        'Dynamic Programming': {
          subject: 'Data Structures & Algorithms',
          topic: 'Dynamic Programming',
          attempts: 4,
          attemptsCount: 4,
          bestScore: 60,
          lastScore: 55,
          averageScore: 58,
          masteryLevel: 'Needs Revision',
          lastAttemptDate: 'Yesterday',
        },
        'Graph Algorithms (Dijkstra, BFS, DFS)': {
          subject: 'Data Structures & Algorithms',
          topic: 'Graph Algorithms (Dijkstra, BFS, DFS)',
          attempts: 5,
          attemptsCount: 5,
          bestScore: 100,
          lastScore: 90,
          averageScore: 92,
          masteryLevel: 'Mastered',
          lastAttemptDate: 'Yesterday',
        },
        'Binary Search Trees & AVL': {
          subject: 'Data Structures & Algorithms',
          topic: 'Binary Search Trees & AVL',
          attempts: 3,
          attemptsCount: 3,
          bestScore: 65,
          lastScore: 60,
          averageScore: 62,
          masteryLevel: 'Developing',
          lastAttemptDate: '2 days ago',
        },
      },
    };
  });

  // 12. Personalized AI Study Plan
  const [studyPlan, setStudyPlan] = useState<PersonalizedStudyPlan | null>(() => {
    const saved = localStorage.getItem('examfocus_study_plan');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return null;
  });

  // 13. Badges and Milestones
  const [badges, setBadges] = useState<BadgeItem[]>(() => {
    const saved = localStorage.getItem('examfocus_badges');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return INITIAL_BADGES;
  });

  // 14. Leaderboard
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>(() => {
    const saved = localStorage.getItem('examfocus_leaderboard');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return INITIAL_LEADERBOARD;
  });

  // 15. Recently Studied Items
  const [recentlyStudied, setRecentlyStudied] = useState<RecentlyStudiedItem[]>(() => {
    const saved = localStorage.getItem('examfocus_recently_studied');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return INITIAL_RECENT_STUDIES;
  });

  // 16. Modal state for simulated app testing
  const [simulatedApp, setSimulatedApp] = useState<DistractingApp | null>(null);

  // Persistence effects
  useEffect(() => {
    localStorage.setItem('examfocus_field', currentField);
  }, [currentField]);

  useEffect(() => {
    localStorage.setItem(`examfocus_exams_${currentField}`, JSON.stringify(exams));
  }, [exams, currentField]);

  useEffect(() => {
    localStorage.setItem('examfocus_apps', JSON.stringify(apps));
  }, [apps]);

  useEffect(() => {
    localStorage.setItem('examfocus_pass', JSON.stringify(screenTimePass));
  }, [screenTimePass]);

  useEffect(() => {
    localStorage.setItem('examfocus_penalty', JSON.stringify(penaltyState));
  }, [penaltyState]);

  useEffect(() => {
    localStorage.setItem('examfocus_progress', JSON.stringify(userProgress));
  }, [userProgress]);

  useEffect(() => {
    localStorage.setItem('examfocus_perf_profile', JSON.stringify(performanceProfile));
  }, [performanceProfile]);

  useEffect(() => {
    if (studyPlan) {
      localStorage.setItem('examfocus_study_plan', JSON.stringify(studyPlan));
    }
  }, [studyPlan]);

  useEffect(() => {
    localStorage.setItem('examfocus_badges', JSON.stringify(badges));
  }, [badges]);

  useEffect(() => {
    localStorage.setItem('examfocus_leaderboard', JSON.stringify(leaderboard));
  }, [leaderboard]);

  useEffect(() => {
    localStorage.setItem('examfocus_recently_studied', JSON.stringify(recentlyStudied));
  }, [recentlyStudied]);

  // Master 1-second Tick Interval for Screen Time Pass & 30-Minute Penalty
  useEffect(() => {
    const interval = setInterval(() => {
      // 1. Tick penalty down if active
      setPenaltyState((prev) => {
        if (!prev.active) return prev;
        if (prev.remainingSeconds <= 1) {
          return { ...prev, active: false, remainingSeconds: 0 };
        }
        return { ...prev, remainingSeconds: prev.remainingSeconds - 1 };
      });

      // 2. Tick screen time pass down if active and not penalized
      setScreenTimePass((prev) => {
        if (!prev.active) return prev;
        if (prev.remainingSeconds <= 1) {
          return {
            ...prev,
            active: false,
            remainingSeconds: 0,
            expiresAt: null,
          };
        }
        return { ...prev, remainingSeconds: prev.remainingSeconds - 1 };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Handle changing academic field
  const handleFieldChange = (newField: AcademicField) => {
    if (isQuizActive) return;
    setCurrentField(newField);
    const newExams = PRESET_TIMETABLES[newField] || PRESET_TIMETABLES['B.Tech / Engineering'];
    setExams(newExams);
    setSelectedExamForStudy(null);
    setSelectedTopicForStudy('');
  };

  // Select exam for AI study tutor
  const handleSelectExamForStudy = (exam: ExamItem, topic?: string) => {
    if (isQuizActive) return;
    setSelectedExamForStudy(exam);
    setSelectedTopicForStudy(topic || exam.syllabusTopics[0] || '');
    setActiveTab('tutor');
  };

  // Select exam for taking a quiz
  const handleSelectExamForQuiz = (exam: ExamItem, topic?: string) => {
    setSelectedExamForStudy(exam);
    setSelectedTopicForStudy(topic || exam.syllabusTopics[0] || '');
    setActiveTab('quiz');
  };

  // Trigger 30-Minute Penalty Lock (Strict penalty for quiz abandonment)
  const handleTriggerPenalty = (reason: string) => {
    const penaltyDuration = 1800; // 30 minutes in seconds
    const now = Date.now();

    setPenaltyState({
      active: true,
      reason,
      startedAt: now,
      durationSeconds: penaltyDuration,
      remainingSeconds: penaltyDuration,
    });

    // Revoke any active screen time pass immediately
    setScreenTimePass({
      active: false,
      totalMinutes: 0,
      remainingSeconds: 0,
      unlockedAt: null,
      expiresAt: null,
      sourceQuizSubject: '',
    });

    setUserProgress((prev) => ({
      ...prev,
      penaltyCount: prev.penaltyCount + 1,
    }));

    // Switch to apps blocker view to display locked shield
    setActiveTab('apps');
  };

  // Handle Quiz completion, Adaptive Performance Profile update, XP & Reward grant
  const handleQuizCompleted = (scorePercentage: number, subject: string, topic: string) => {
    // 1. Calculate screen time pass reward
    // Score >= 80% -> 30 minutes
    // Score 60-79% -> 15 minutes
    let earnedMinutes = 0;
    let earnedXp = 50;

    if (scorePercentage >= 80) {
      earnedMinutes = 30;
      earnedXp = 150;
    } else if (scorePercentage >= 60) {
      earnedMinutes = 15;
      earnedXp = 75;
    } else {
      earnedXp = 25;
    }

    if (earnedMinutes > 0) {
      const now = Date.now();
      const expiresAt = now + earnedMinutes * 60 * 1000;

      setScreenTimePass({
        active: true,
        totalMinutes: earnedMinutes,
        remainingSeconds: earnedMinutes * 60,
        unlockedAt: now,
        expiresAt,
        sourceQuizSubject: subject,
      });
    }

    // 2. Update Gamification Progress (XP, Level, Badges)
    let newXpTotal = userProgress.xp + earnedXp;
    setUserProgress((prev) => {
      const nextXp = prev.xp + earnedXp;
      const nextLevel = Math.floor(nextXp / 300) + 1;
      return {
        ...prev,
        xp: nextXp,
        level: nextLevel,
        quizzesCompleted: prev.quizzesCompleted + 1,
        rewardsUnlocked: earnedMinutes > 0 ? prev.rewardsUnlocked + 1 : prev.rewardsUnlocked,
        totalStudyMinutes: prev.totalStudyMinutes + (earnedMinutes > 0 ? earnedMinutes : 15),
      };
    });

    // 3. Update Adaptive Performance Profile
    setPerformanceProfile((prev) => {
      const isWeak = scorePercentage < 70;
      const isMastered = scorePercentage >= 80;

      const newWeak = isWeak
        ? Array.from(new Set([...prev.weakTopics, topic]))
        : prev.weakTopics.filter((t) => t.toLowerCase() !== topic.toLowerCase());

      const newMastered = isMastered
        ? Array.from(new Set([...prev.masteredTopics, topic]))
        : prev.masteredTopics.filter((t) => t.toLowerCase() !== topic.toLowerCase());

      const oldRecord = prev.topicRecords[topic] || {
        subject,
        topic,
        attempts: 0,
        attemptsCount: 0,
        bestScore: 0,
        lastScore: 0,
        averageScore: 0,
        masteryLevel: 'Developing' as const,
        lastAttemptDate: new Date().toLocaleDateString(),
      };

      const newAttempts = (oldRecord.attempts || oldRecord.attemptsCount || 0) + 1;
      const newBest = Math.max(oldRecord.bestScore || 0, scorePercentage);
      const totalCount = (prev.totalQuizzes || prev.totalQuizzesTaken || 0) + 1;
      const newAvg = Math.round(((prev.averageScore || 75) * (totalCount - 1) + scorePercentage) / totalCount);
      const newDifficulty = newAvg >= 85 ? 'Exam Mock' : newAvg >= 75 ? 'Hard' : 'Medium';

      return {
        ...prev,
        totalQuizzes: totalCount,
        totalQuizzesTaken: totalCount,
        recommendedDifficulty: newDifficulty,
        weakTopics: newWeak,
        masteredTopics: newMastered,
        averageScore: newAvg,
        topicRecords: {
          ...prev.topicRecords,
          [topic]: {
            ...oldRecord,
            subject,
            topic,
            attempts: newAttempts,
            attemptsCount: newAttempts,
            bestScore: newBest,
            lastScore: scorePercentage,
            averageScore: Math.round(((oldRecord.averageScore || scorePercentage) + scorePercentage) / 2),
            masteryLevel: isMastered ? 'Mastered' : isWeak ? 'Needs Revision' : 'Developing',
            lastAttemptDate: 'Just now',
          },
        },
      };
    });

    // 4. Update Milestone Badges
    setBadges((prevBadges) =>
      prevBadges.map((badge) => {
        if (badge.id === 'perfect-quiz' && scorePercentage === 100 && !badge.unlocked) {
          return { ...badge, unlocked: true, unlockedAt: 'Just now' };
        }
        if (badge.id === 'screen-master' && scorePercentage >= 80 && !badge.unlocked) {
          return { ...badge, unlocked: true, unlockedAt: 'Just now' };
        }
        if (badge.id === 'deep-diver' && scorePercentage >= 80 && performanceProfile.weakTopics.includes(topic)) {
          return { ...badge, unlocked: true, unlockedAt: 'Just now', progressText: `Mastered ${topic}!` };
        }
        return badge;
      })
    );

    // 5. Update Leaderboard position
    setLeaderboard((prevBoard) => {
      const updated = prevBoard.map((entry) => {
        if (entry.isCurrentUser) {
          return {
            ...entry,
            xp: newXpTotal,
            quizzesPassed: entry.quizzesPassed + (scorePercentage >= 60 ? 1 : 0),
          };
        }
        return entry;
      });
      // Re-sort by XP
      updated.sort((a, b) => b.xp - a.xp);
      return updated.map((item, idx) => ({ ...item, rank: idx + 1 }));
    });

    // 6. Record to Recently Studied
    const newRecord: RecentlyStudiedItem = {
      id: `rec-${Date.now()}`,
      courseName: subject,
      topic: topic,
      startTime: new Date(Date.now() - 15 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      endTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      totalTimeSpent: '15m Quiz',
      date: 'Just now',
      xpEarned: earnedXp,
    };
    setRecentlyStudied((prev) => [newRecord, ...prev.slice(0, 9)]);
  };

  // End break early bonus
  const handleEndBreakEarly = () => {
    setScreenTimePass({
      active: false,
      totalMinutes: 0,
      remainingSeconds: 0,
      unlockedAt: null,
      expiresAt: null,
      sourceQuizSubject: '',
    });
    setUserProgress((prev) => ({
      ...prev,
      xp: prev.xp + 50,
    }));
    setSimulatedApp(null);
  };

  // Find nearest upcoming exam
  const nearestExam = exams[0] || null;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* 30-Minute Penalty Notification Banner */}
      <PenaltyBanner penaltyState={penaltyState} />

      {/* Main Navigation Header */}
      <Header
        currentField={currentField}
        onFieldChange={handleFieldChange}
        screenTimePass={screenTimePass}
        penaltyState={penaltyState}
        userProgress={userProgress}
        focusModeEnabled={focusModeEnabled}
        onToggleFocusMode={() => setFocusModeEnabled(!focusModeEnabled)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isQuizActive={isQuizActive}
      />

      {/* Main Content Layout with Sidebar */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-6 gap-6">
        {/* Persistent Desktop Sidebar */}
        <div className="hidden lg:block w-64 shrink-0">
          <Sidebar
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            isQuizActive={isQuizActive}
            screenTimePass={screenTimePass}
            penaltyState={penaltyState}
            userProgress={userProgress}
          />
        </div>

        {/* Dynamic Workspace Container */}
        <main className="flex-1 min-w-0 space-y-6">
          {/* TAB 1: DASHBOARD VIEW (Course.AI style with focus timer, charts, schedule) */}
          {activeTab === 'dashboard' && (
            <DashboardView
              currentField={currentField}
              exams={exams}
              userProgress={userProgress}
              performanceProfile={performanceProfile}
              studyPlan={studyPlan}
              recentlyStudied={recentlyStudied}
              screenTimePass={screenTimePass}
              penaltyState={penaltyState}
              isQuizActive={isQuizActive}
              onNavigateToQuiz={(subj, top) => {
                if (subj) {
                  const exam = exams.find((e) => e.subject === subj) || exams[0];
                  handleSelectExamForQuiz(exam, top);
                } else {
                  setActiveTab('quiz');
                }
              }}
              onNavigateToTutor={(subj, top) => {
                if (subj) {
                  const exam = exams.find((e) => e.subject === subj) || exams[0];
                  handleSelectExamForStudy(exam, top);
                } else {
                  setActiveTab('tutor');
                }
              }}
              onNavigateToStudyPlan={() => setActiveTab('study-plan')}
              onNavigateToTimetable={() => setActiveTab('timetable')}
              onAddXP={(amount) => {
                setUserProgress((prev) => {
                  const nextXp = prev.xp + amount;
                  return {
                    ...prev,
                    xp: nextXp,
                    level: Math.floor(nextXp / 300) + 1,
                  };
                });
              }}
            />
          )}

          {/* TAB 2: AI PERSONALIZED STUDY PLAN */}
          {activeTab === 'study-plan' && (
            <AIStudyPlanView
              currentField={currentField}
              exams={exams}
              performanceProfile={performanceProfile}
              studyPlan={studyPlan}
              setStudyPlan={setStudyPlan}
              isQuizActive={isQuizActive}
              onNavigateToQuiz={(subject: string, topic: string) => {
                const foundExam = exams.find((e) => e.subject === subject) || exams[0];
                handleSelectExamForQuiz(foundExam, topic);
              }}
              onNavigateToTutor={(subject: string, topic: string) => {
                const foundExam = exams.find((e) => e.subject === subject) || exams[0];
                handleSelectExamForStudy(foundExam, topic);
              }}
            />
          )}

          {/* TAB 3: UPLOAD TIMETABLE & EXAM SCHEDULE */}
          {activeTab === 'timetable' && (
            <TimetableUploader
              currentField={currentField}
              exams={exams}
              setExams={setExams}
              onSelectExamForStudy={handleSelectExamForStudy}
              onSelectExamForQuiz={handleSelectExamForQuiz}
              isQuizActive={isQuizActive}
            />
          )}

          {/* TAB 4: AI STUDY TUTOR & DOUBT CLARIFICATION */}
          {activeTab === 'tutor' && (
            <AIStudyTutor
              currentField={currentField}
              selectedExam={selectedExamForStudy || exams[0] || null}
              selectedTopic={selectedTopicForStudy || (exams[0]?.syllabusTopics[0] ?? '')}
              isQuizActive={isQuizActive}
              onLaunchQuizForTopic={(subj, top) => {
                setSelectedExamForStudy(exams.find((e) => e.subject === subj) || null);
                setSelectedTopicForStudy(top);
                setActiveTab('quiz');
              }}
              performanceProfile={performanceProfile}
              onNavigateToStudyPlan={() => setActiveTab('study-plan')}
            />
          )}

          {/* TAB 5: STUDY QUIZ & EARN SCREEN TIME FLOW */}
          {activeTab === 'quiz' && (
            <QuizModule
              currentField={currentField}
              exams={exams}
              isQuizActive={isQuizActive}
              setIsQuizActive={setIsQuizActive}
              onQuizCompleted={handleQuizCompleted}
              onTriggerPenalty={handleTriggerPenalty}
              onNavigateToTutor={(subj, top) => {
                setSelectedExamForStudy(exams.find((e) => e.subject === subj) || null);
                setSelectedTopicForStudy(top);
                setActiveTab('tutor');
              }}
              preSelectedSubject={selectedExamForStudy?.subject}
              preSelectedTopic={selectedTopicForStudy}
              performanceProfile={performanceProfile}
            />
          )}

          {/* TAB 6: DISTRACTION BLOCKER & PASS SIMULATOR */}
          {activeTab === 'apps' && (
            <DistractionBlocker
              apps={apps}
              setApps={setApps}
              focusModeEnabled={focusModeEnabled}
              onToggleFocusMode={() => setFocusModeEnabled(!focusModeEnabled)}
              screenTimePass={screenTimePass}
              penaltyState={penaltyState}
              onOpenAppSimulation={(app) => setSimulatedApp(app)}
              onNavigateToQuiz={() => setActiveTab('quiz')}
            />
          )}

          {/* TAB 7: GAMIFIED LEADERBOARD & BADGES */}
          {activeTab === 'leaderboard' && (
            <LeaderboardAndBadges
              badges={badges}
              leaderboard={leaderboard}
              userProgress={userProgress}
            />
          )}
        </main>
      </div>

      {/* Interactive App Sandbox Modal (Tests Blocker, Screen Time Pass, and Penalty Lock) */}
      <SimulatedAppModal
        app={simulatedApp}
        onClose={() => setSimulatedApp(null)}
        screenTimePass={screenTimePass}
        penaltyState={penaltyState}
        onNavigateToQuiz={() => {
          setSimulatedApp(null);
          setActiveTab('quiz');
        }}
        onEndBreakEarly={handleEndBreakEarly}
        nearestExam={nearestExam}
      />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 text-center text-xs text-slate-500">
        <p>
          Exam Focus &bull; “First Study, Then Earn Your Screen Time” &bull; Adaptive AI Diagnostics & Gamified Mastery
        </p>
      </footer>
    </div>
  );
}
