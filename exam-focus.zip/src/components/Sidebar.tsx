import React from 'react';
import {
  LayoutDashboard,
  Calendar,
  Bot,
  Zap,
  Shield,
  Trophy,
  BookOpen,
  Settings,
  Sparkles,
  Lock,
  ChevronRight,
  LogOut,
} from 'lucide-react';
import { AcademicField, ScreenTimePass, PenaltyState, UserProgress } from '../types';
import { studyFutureGoalsImg } from '../assets/images';

export type ActiveNavTab =
  | 'dashboard'
  | 'study-plan'
  | 'tutor'
  | 'timetable'
  | 'quiz'
  | 'apps'
  | 'leaderboard';

interface SidebarProps {
  activeTab: ActiveNavTab;
  setActiveTab: (tab: ActiveNavTab) => void;
  currentField?: AcademicField;
  isQuizActive: boolean;
  screenTimePass: ScreenTimePass;
  penaltyState: PenaltyState;
  userProgress?: UserProgress;
  collapsed?: boolean;
  onToggleCollapse?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  currentField = 'B.Tech / Engineering',
  isQuizActive,
  screenTimePass,
  penaltyState,
  userProgress,
}) => {
  const navItems = [
    {
      id: 'dashboard' as ActiveNavTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'study-plan' as ActiveNavTab,
      label: 'AI Study Plan',
      icon: Sparkles,
      badge: 'Adaptive',
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    },
    {
      id: 'timetable' as ActiveNavTab,
      label: 'My Timetable',
      icon: Calendar,
      badge: null,
    },
    {
      id: 'tutor' as ActiveNavTab,
      label: 'AI Study Tutor',
      icon: Bot,
      badge: isQuizActive ? 'Locked' : 'Online',
      badgeColor: isQuizActive
        ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
        : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
      disabled: isQuizActive,
    },
    {
      id: 'quiz' as ActiveNavTab,
      label: 'Quizzes & Mock Tests',
      icon: Zap,
      badge: isQuizActive ? 'Active' : 'Earn Pass',
      badgeColor: isQuizActive
        ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
        : 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    },
    {
      id: 'apps' as ActiveNavTab,
      label: 'Distraction Shield',
      icon: Shield,
      badge: penaltyState.active ? 'Penalty' : screenTimePass.active ? 'Pass ON' : 'Active',
      badgeColor: penaltyState.active
        ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
        : screenTimePass.active
        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
        : 'bg-slate-700 text-slate-300 border-slate-600',
    },
    {
      id: 'leaderboard' as ActiveNavTab,
      label: 'Badges & Ranks',
      icon: Trophy,
      badge: 'XP Top 10',
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    },
  ];

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800 flex flex-col justify-between shrink-0 h-screen sticky top-0 select-none z-30">
      {/* Brand Header */}
      <div>
        <div className="p-5 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-500 via-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/25">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-white tracking-tight text-base">Course</span>
                <span className="font-bold text-indigo-400 text-base">.AI</span>
                <span className="text-[9px] uppercase tracking-wider bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded font-bold border border-indigo-500/30">
                  Focus
                </span>
              </div>
              <p className="text-[10px] text-slate-400 truncate max-w-[130px]">
                {currentField.split('/')[0]}
              </p>
            </div>
          </div>
        </div>

        {/* Navigation items */}
        <div className="px-3 py-4 space-y-1">
          <div className="px-3 pb-2 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
            Menu
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  if (item.disabled) return;
                  setActiveTab(item.id);
                }}
                disabled={item.disabled}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all group ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/25'
                    : item.disabled
                    ? 'text-slate-600 cursor-not-allowed opacity-50'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900/80'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 transition-colors ${
                      isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-wider ${
                      item.badgeColor || 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom Profile & Shield Status Card */}
      <div className="p-3 border-t border-slate-800/80 space-y-2">
        {/* Visual Motivational Pill */}
        <div className="relative rounded-xl overflow-hidden border border-slate-800 group shadow-md">
          <img
            src={studyFutureGoalsImg}
            alt="Build Your Future"
            referrerPolicy="no-referrer"
            className="w-full h-16 object-cover object-center group-hover:scale-105 transition-transform duration-500 opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />
          <div className="absolute inset-0 p-2.5 flex flex-col justify-end">
            <span className="text-[9px] font-black text-amber-300 uppercase tracking-wider">
              Study First &bull; Earn Pass
            </span>
            <p className="text-[10px] font-bold text-white truncate">
              Your free time builds your future
            </p>
          </div>
        </div>

        {/* Status Mini Indicator */}
        <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 text-xs">
          <div className="flex items-center justify-between text-slate-300 mb-1">
            <span className="flex items-center gap-1.5 font-semibold text-[11px]">
              {penaltyState.active ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                  <span className="text-rose-400">Penalty Lock Active</span>
                </>
              ) : screenTimePass.active ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-emerald-300">Screen Pass Active</span>
                </>
              ) : (
                <>
                  <span className="w-2 h-2 rounded-full bg-indigo-400" />
                  <span className="text-slate-300">Exam Shield Ready</span>
                </>
              )}
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-tight">
            {penaltyState.active
              ? 'Social media locked for 30m due to abandoned quiz.'
              : screenTimePass.active
              ? 'Enjoy your earned recreational break!'
              : 'Pass quizzes with 80%+ to unlock 15-30m passes.'}
          </p>
        </div>

        {/* User profile capsule */}
        <div className="flex items-center justify-between p-2 rounded-xl bg-slate-900/50 border border-slate-800/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold shadow">
              AC
            </div>
            <div>
              <p className="text-xs font-bold text-white leading-tight">Alex Chen</p>
              <p className="text-[10px] text-indigo-400">Level 6 Scholar</p>
            </div>
          </div>
          <div className="text-slate-500 hover:text-slate-300 cursor-pointer p-1">
            <Settings className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>
    </aside>
  );
};
