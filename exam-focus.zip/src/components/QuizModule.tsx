import React, { useState, useEffect, useCallback } from 'react';
import confetti from 'canvas-confetti';
import {
  Award,
  Clock,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ArrowRight,
  RotateCcw,
  Sparkles,
  Zap,
  Lock,
  Unlock,
  BookOpen,
} from 'lucide-react';
import { AcademicField, ExamItem, QuizQuestion, StudentPerformanceProfile } from '../types';
import { DEFAULT_QUESTIONS_BY_FIELD } from '../data/mockData';
import { gradLightbulbLadderImg, deepFocusNightImg, studyFutureGoalsImg } from '../assets/images';

interface QuizModuleProps {
  currentField: AcademicField;
  exams: ExamItem[];
  isQuizActive: boolean;
  setIsQuizActive: (active: boolean) => void;
  onQuizCompleted: (scorePercentage: number, subject: string, topic: string) => void;
  onTriggerPenalty: (reason: string) => void;
  onNavigateToTutor: (subject: string, topic: string) => void;
  preSelectedSubject?: string;
  preSelectedTopic?: string;
  performanceProfile?: StudentPerformanceProfile;
}

export const QuizModule: React.FC<QuizModuleProps> = ({
  currentField,
  exams,
  isQuizActive,
  setIsQuizActive,
  onQuizCompleted,
  onTriggerPenalty,
  onNavigateToTutor,
  preSelectedSubject,
  preSelectedTopic,
  performanceProfile,
}) => {
  // Setup state
  const [selectedSubject, setSelectedSubject] = useState(
    preSelectedSubject || (exams[0]?.subject ?? 'Data Structures & Algorithms')
  );
  const [selectedTopic, setSelectedTopic] = useState(
    preSelectedTopic || (exams[0]?.syllabusTopics[0] ?? 'Dynamic Programming')
  );
  const [questionCount, setQuestionCount] = useState<number>(5);
  const [difficulty, setDifficulty] = useState<'Medium' | 'Hard' | 'Exam Mock'>('Medium');
  const [useAdaptiveTuning, setUseAdaptiveTuning] = useState(true);
  const [isLoadingQuiz, setIsLoadingQuiz] = useState(false);

  // Active quiz state
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showHint, setShowHint] = useState(false);
  const [quizTimeRemaining, setQuizTimeRemaining] = useState<number>(300); // 5 minutes default
  const [showAbandonModal, setShowAbandonModal] = useState(false);
  const [tabSwitchWarnings, setTabSwitchWarnings] = useState<number>(0);

  // Completed results state
  const [quizFinished, setQuizFinished] = useState(false);
  const [finalScore, setFinalScore] = useState<{
    correct: number;
    total: number;
    percentage: number;
    earnedMinutes: number;
  } | null>(null);

  // Sync props if changed
  useEffect(() => {
    if (preSelectedSubject) setSelectedSubject(preSelectedSubject);
    if (preSelectedTopic) setSelectedTopic(preSelectedTopic);
  }, [preSelectedSubject, preSelectedTopic]);

  // Tab switch & Window blur detection (Anti-cheat & Anti-abandon)
  useEffect(() => {
    if (!isQuizActive || quizFinished) return;

    const handleVisibilityChange = () => {
      if (document.hidden) {
        setTabSwitchWarnings((prev) => {
          const next = prev + 1;
          if (next >= 2) {
            // Second strike triggers penalty
            handleAbandonConfirmed('Detected multiple tab switches / window blur during strict quiz session.');
          }
          return next;
        });
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isQuizActive, quizFinished]);

  // Quiz timer countdown
  useEffect(() => {
    if (!isQuizActive || quizFinished) return;

    const timer = setInterval(() => {
      setQuizTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleFinishQuiz();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isQuizActive, quizFinished]);

  // Start quiz handler
  const handleStartQuiz = async () => {
    setIsLoadingQuiz(true);
    setQuizFinished(false);
    setFinalScore(null);
    setCurrentQuestionIndex(0);
    setSelectedAnswers({});
    setShowHint(false);
    setTabSwitchWarnings(0);

    try {
      // Call server backend quiz endpoint with adaptive tuning
      const response = await fetch('/api/quiz/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          academicField: currentField,
          subject: selectedSubject,
          topic: selectedTopic,
          questionCount,
          difficulty: useAdaptiveTuning && isWeakTopic ? 'Medium' : difficulty,
          performanceProfile: useAdaptiveTuning ? performanceProfile : undefined,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate quiz from server');
      }

      const data = await response.json();
      if (data.questions && data.questions.length > 0) {
        setQuestions(data.questions);
      } else {
        // Fallback to rich subject bank
        const fallback =
          DEFAULT_QUESTIONS_BY_FIELD[selectedSubject] ||
          DEFAULT_QUESTIONS_BY_FIELD['Default'];
        setQuestions(fallback.slice(0, questionCount));
      }
    } catch (err) {
      console.warn('Using local question bank fallback', err);
      const fallback =
        DEFAULT_QUESTIONS_BY_FIELD[selectedSubject] ||
        DEFAULT_QUESTIONS_BY_FIELD['Default'];
      setQuestions(fallback.slice(0, questionCount));
    } finally {
      setIsLoadingQuiz(false);
      setIsQuizActive(true); // Locks AI chatbot!
      setQuizTimeRemaining(questionCount * 60); // 1 minute per question
    }
  };

  // Select an option
  const handleSelectOption = (questionId: number, optionIndex: number) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionId]: optionIndex,
    }));
  };

  // Submit and grade quiz
  const handleFinishQuiz = useCallback(() => {
    let correct = 0;
    questions.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctIndex) {
        correct++;
      }
    });

    const total = questions.length || 1;
    const percentage = Math.round((correct / total) * 100);

    let earnedMinutes = 0;
    if (percentage >= 80) {
      earnedMinutes = 30; // 30 min pass for score >= 80%
      // Trigger confetti celebration
      try {
        confetti({
          particleCount: 120,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (e) {
        // Safe fallback
      }
    } else if (percentage >= 60) {
      earnedMinutes = 15; // 15 min pass for score 60-79%
    }

    setFinalScore({
      correct,
      total,
      percentage,
      earnedMinutes,
    });

    setIsQuizActive(false); // Re-enables AI chatbot!
    setQuizFinished(true);

    onQuizCompleted(percentage, selectedSubject, selectedTopic);
  }, [questions, selectedAnswers, selectedSubject, selectedTopic, setIsQuizActive, onQuizCompleted]);

  // Abandon quiz -> Triggers 30-minute penalty
  const handleAbandonConfirmed = (customReason?: string) => {
    setShowAbandonModal(false);
    setIsQuizActive(false);
    setQuizFinished(false);
    setQuestions([]);
    onTriggerPenalty(
      customReason ||
        'Exited / abandoned an ongoing exam focus quiz early. Strict 30-minute penalty imposed.'
    );
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Find active exam topics
  const currentExamObj = exams.find((e) => e.subject === selectedSubject);

  const isWeakTopic = performanceProfile?.weakTopics?.some(
    (w) => w.toLowerCase().includes(selectedTopic.toLowerCase()) || selectedTopic.toLowerCase().includes(w.toLowerCase())
  );
  const isMasteredTopic = performanceProfile?.masteredTopics?.some(
    (m) => m.toLowerCase().includes(selectedTopic.toLowerCase()) || selectedTopic.toLowerCase().includes(m.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* 1. SETUP VIEW (Before quiz starts) */}
      {!isQuizActive && !quizFinished && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 relative overflow-hidden shadow-xl group">
          {/* Subtle Graduation Ladder Backdrop Ambiance */}
          <img
            src={gradLightbulbLadderImg}
            alt="Knowledge Ladder"
            referrerPolicy="no-referrer"
            className="absolute -right-10 top-0 w-80 h-full object-cover object-center opacity-15 group-hover:opacity-25 transition-opacity duration-700 pointer-events-none hidden md:block"
          />
          <div className="absolute right-0 top-0 w-80 h-full bg-gradient-to-l from-transparent via-slate-900/80 to-slate-900 pointer-events-none hidden md:block" />

          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 mb-6 relative z-10">
            <div className="max-w-xl">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold mb-3">
                <Zap className="w-3.5 h-3.5" />
                Study &rarr; Test &rarr; Score &ge; 80% &rarr; Earn Screen Time
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                Exam Readiness Quiz & Reward Challenge
              </h2>
              <p className="text-sm text-slate-300 mt-1.5 leading-relaxed">
                Test your mastery on any topic from your timetable. Score <strong>80% or higher</strong> to unlock
                <strong> 30 minutes of screen time</strong> on Instagram, YouTube, and games.
              </p>
            </div>

            {/* Reward tiers summary */}
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4 min-w-[280px] space-y-2 text-xs">
              <h4 className="font-bold text-white flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-400" /> Reward Tiers
              </h4>
              <div className="flex justify-between items-center text-emerald-300 bg-emerald-500/10 px-2 py-1 rounded">
                <span>Score &ge; 80%:</span>
                <span className="font-bold">30 Mins Unlocked + 150 XP</span>
              </div>
              <div className="flex justify-between items-center text-indigo-300 bg-indigo-500/10 px-2 py-1 rounded">
                <span>Score 60% - 79%:</span>
                <span className="font-bold">15 Mins Unlocked + 75 XP</span>
              </div>
              <div className="flex justify-between items-center text-rose-300 bg-rose-500/10 px-2 py-1 rounded">
                <span>Abandon Early / Quit:</span>
                <span className="font-bold">30-Min Penalty Lock</span>
              </div>
            </div>
          </div>

          {/* Adaptive Tuning & Diagnosis Alert */}
          {performanceProfile && (
            <div
              className={`p-4 rounded-xl border mb-6 flex items-start justify-between gap-3 text-xs ${
                isWeakTopic
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-200'
                  : isMasteredTopic
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
                  : 'bg-indigo-500/10 border-indigo-500/30 text-indigo-200'
              }`}
            >
              <div className="flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 shrink-0 mt-0.5" />
                <div>
                  <strong className="block font-bold mb-0.5 text-white">
                    {isWeakTopic
                      ? '🎯 Adaptive Diagnostic Mode: Identified Weak Area'
                      : isMasteredTopic
                      ? '🔥 Adaptive Mastery Mode: High Performance History'
                      : '⚡ Adaptive Content Engine Active'}
                  </strong>
                  <p className="leading-relaxed opacity-90">
                    {isWeakTopic
                      ? `"${selectedTopic}" is flagged in your performance profile with past scores < 70%. The AI will prioritize diagnostic questions with memory anchors.`
                      : isMasteredTopic
                      ? `"${selectedTopic}" is marked as Mastered (avg score ≥ 80%). The AI will challenge you with multi-concept synthesis questions.`
                      : `Questions will be calibrated automatically based on your overall ${performanceProfile.averageScore}% average score.`}
                  </p>
                </div>
              </div>

              <label className="flex items-center gap-2 cursor-pointer shrink-0 font-medium text-white">
                <input
                  type="checkbox"
                  checked={useAdaptiveTuning}
                  onChange={(e) => setUseAdaptiveTuning(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span className="hidden sm:inline">Auto-Tuning</span>
              </label>
            </div>
          )}

          {/* Form parameters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 rounded-xl bg-slate-800/50 border border-slate-700/60 mb-6">
            {/* Subject selector */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Exam Subject
              </label>
              <select
                value={selectedSubject}
                onChange={(e) => {
                  setSelectedSubject(e.target.value);
                  const found = exams.find((ex) => ex.subject === e.target.value);
                  if (found && found.syllabusTopics[0]) {
                    setSelectedTopic(found.syllabusTopics[0]);
                  }
                }}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {exams.map((ex) => (
                  <option key={ex.id} value={ex.subject}>
                    {ex.subject}
                  </option>
                ))}
              </select>
            </div>

            {/* Topic selector */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Topic / Module
              </label>
              <input
                type="text"
                value={selectedTopic}
                onChange={(e) => setSelectedTopic(e.target.value)}
                placeholder="e.g. Dynamic Programming, Cardiovascular Anatomy"
                className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              {currentExamObj && currentExamObj.syllabusTopics.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {currentExamObj.syllabusTopics.slice(0, 3).map((top, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedTopic(top)}
                      className="text-[10px] text-slate-400 hover:text-indigo-300 underline"
                    >
                      {top}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Question count & Difficulty */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Questions
                </label>
                <select
                  value={questionCount}
                  onChange={(e) => setQuestionCount(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value={5}>5 Questions</option>
                  <option value={8}>8 Questions</option>
                  <option value={10}>10 Questions</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Difficulty
                </label>
                <select
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Medium">Medium</option>
                  <option value="Hard">Hard</option>
                  <option value="Exam Mock">Exam Mock</option>
                </select>
              </div>
            </div>
          </div>

          {/* Strict Rule Notice */}
          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 mb-6 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-200/90 leading-relaxed">
              <strong className="text-amber-300 font-semibold block mb-0.5">
                Strict Exam Integrity Rules:
              </strong>
              1. Once started, the <strong>AI Chatbot will be paused</strong> until the quiz concludes.<br />
              2. <strong>Do not leave or switch tabs</strong> during the quiz. Abandoning an ongoing test incurs an
              immediate <strong>30-Minute Penalty Lockout</strong> where all entertainment apps remain strictly blocked.
            </div>
          </div>

          {/* Launch Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <button
              onClick={() => onNavigateToTutor(selectedSubject, selectedTopic)}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1.5"
            >
              <BookOpen className="w-4 h-4" />
              Not ready? Review topic with Socrates-AI first
            </button>

            <button
              id="start-exam-quiz-btn"
              onClick={handleStartQuiz}
              disabled={isLoadingQuiz}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2"
            >
              {isLoadingQuiz ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin" />
                  Generating Exam Questions...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  Start Timed Quiz & Earn Screen Time
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* 2. ACTIVE QUIZ VIEW */}
      {isQuizActive && questions.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl relative">
          {/* Active Quiz Header & Timer */}
          <div className="p-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Question {currentQuestionIndex + 1} of {questions.length}
              </span>
              <span className="text-xs text-slate-400 hidden sm:inline">
                {selectedSubject} &bull; {selectedTopic}
              </span>
            </div>

            {/* Countdown timer & Abandon button */}
            <div className="flex items-center gap-3">
              <div
                className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-mono font-bold ${
                  quizTimeRemaining < 60
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse'
                    : 'bg-slate-800 text-slate-200 border border-slate-700'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>{formatTime(quizTimeRemaining)}</span>
              </div>

              <button
                id="abandon-quiz-btn"
                onClick={() => setShowAbandonModal(true)}
                className="px-3 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-semibold transition-colors flex items-center gap-1"
              >
                <XCircle className="w-3.5 h-3.5" />
                Exit (Penalty Risk)
              </button>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-800 h-1.5">
            <div
              className="bg-indigo-500 h-1.5 transition-all duration-300"
              style={{
                width: `${((currentQuestionIndex + 1) / questions.length) * 100}%`,
              }}
            />
          </div>

          {/* Tab switch warning alert banner if triggered */}
          {tabSwitchWarnings > 0 && (
            <div className="bg-rose-500/20 border-b border-rose-500/40 px-4 py-2 flex items-center justify-between text-xs text-rose-300">
              <span className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                Warning: Focus lost! Switching away again will trigger the 30-minute lock penalty.
              </span>
              <span className="font-bold">Strike {tabSwitchWarnings}/2</span>
            </div>
          )}

          {/* Question Content */}
          <div className="p-6">
            {questions[currentQuestionIndex] && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white leading-relaxed">
                    {questions[currentQuestionIndex].question}
                  </h3>
                </div>

                {/* Multiple Choice Options */}
                <div className="space-y-3">
                  {questions[currentQuestionIndex].options.map((option, optIdx) => {
                    const isSelected =
                      selectedAnswers[questions[currentQuestionIndex].id] === optIdx;

                    return (
                      <button
                        key={optIdx}
                        onClick={() =>
                          handleSelectOption(questions[currentQuestionIndex].id, optIdx)
                        }
                        className={`w-full text-left p-4 rounded-xl text-xs sm:text-sm transition-all border flex items-start gap-3 ${
                          isSelected
                            ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-md shadow-indigo-500/10'
                            : 'bg-slate-800/60 border-slate-700/80 text-slate-200 hover:bg-slate-800 hover:border-slate-600'
                        }`}
                      >
                        <span
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${
                            isSelected
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-700 text-slate-300'
                          }`}
                        >
                          {String.fromCharCode(65 + optIdx)}
                        </span>
                        <span className="leading-relaxed">{option}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Hint toggle */}
                {questions[currentQuestionIndex].hint && (
                  <div>
                    {showHint ? (
                      <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-300 flex items-start gap-2">
                        <HelpCircle className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                        <div>
                          <strong>Hint:</strong> {questions[currentQuestionIndex].hint}
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={() => setShowHint(true)}
                        className="text-xs text-slate-400 hover:text-indigo-300 flex items-center gap-1 font-medium transition-colors"
                      >
                        <HelpCircle className="w-3.5 h-3.5" />
                        Need a subtle hint?
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Navigation / Submit Footer */}
          <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between">
            <button
              onClick={() => {
                setShowHint(false);
                setCurrentQuestionIndex((prev) => Math.max(0, prev - 1));
              }}
              disabled={currentQuestionIndex === 0}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Previous
            </button>

            <div className="flex items-center gap-2">
              {currentQuestionIndex < questions.length - 1 ? (
                <button
                  onClick={() => {
                    setShowHint(false);
                    setCurrentQuestionIndex((prev) =>
                      Math.min(questions.length - 1, prev + 1)
                    );
                  }}
                  className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm"
                >
                  <span>Next</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button
                  id="submit-exam-quiz-btn"
                  onClick={handleFinishQuiz}
                  className="px-6 py-2 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/20 flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Submit & Check Score</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3. RESULTS VIEW (After quiz completes) */}
      {quizFinished && finalScore && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 relative overflow-hidden shadow-2xl space-y-6 animate-fadeIn">
          {/* Status banner based on score */}
          <div
            className={`p-6 rounded-2xl border flex flex-col md:flex-row md:items-center md:justify-between gap-6 ${
              finalScore.percentage >= 80
                ? 'bg-emerald-500/10 border-emerald-500/30'
                : finalScore.percentage >= 60
                ? 'bg-indigo-500/10 border-indigo-500/30'
                : 'bg-rose-500/10 border-rose-500/30'
            }`}
          >
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                {finalScore.percentage >= 80 ? (
                  <span className="inline-flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    <Award className="w-3.5 h-3.5" /> Mastery Achieved (&ge; 80%)
                  </span>
                ) : finalScore.percentage >= 60 ? (
                  <span className="inline-flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    <Award className="w-3.5 h-3.5" /> Passing Score (60% - 79%)
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                    <AlertTriangle className="w-3.5 h-3.5" /> Revision Needed (&lt; 60%)
                  </span>
                )}
              </div>

              <h3 className="text-2xl font-bold text-white tracking-tight">
                {finalScore.percentage >= 80
                  ? '🎉 Outstanding! Screen Time Pass Earned!'
                  : finalScore.percentage >= 60
                  ? 'Good Effort! 15-Min Pass Unlocked'
                  : 'Keep Going! Review Concepts & Try Again'}
              </h3>

              <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
                {finalScore.percentage >= 80
                  ? `You scored ${finalScore.percentage}%, successfully demonstrating mastery in ${selectedTopic}. You've earned 30 minutes of unlocked screen time!`
                  : finalScore.percentage >= 60
                  ? `You scored ${finalScore.percentage}%. You have earned 15 minutes of unlocked screen time. Push for 80% on your next quiz for full rewards!`
                  : `You scored ${finalScore.percentage}%. Under the "First Study, Then Earn" principle, reach 80% to unlock distracting apps.`}
              </p>
            </div>

            {/* Big Score Badge */}
            <div className="flex items-center gap-4 bg-slate-900/80 p-4 rounded-xl border border-slate-800">
              <div className="text-center">
                <span className="text-3xl sm:text-4xl font-black text-white">
                  {finalScore.percentage}%
                </span>
                <span className="block text-[10px] text-slate-400 uppercase font-semibold">
                  {finalScore.correct} / {finalScore.total} Correct
                </span>
              </div>

              {finalScore.earnedMinutes > 0 && (
                <div className="border-l border-slate-700 pl-4 text-center">
                  <span className="text-2xl sm:text-3xl font-bold text-emerald-400 flex items-center gap-1">
                    <Unlock className="w-5 h-5" />
                    +{finalScore.earnedMinutes}m
                  </span>
                  <span className="block text-[10px] text-emerald-300/80 uppercase font-semibold">
                    Screen Pass
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Motivational Results Visual Card */}
          <div className="rounded-2xl overflow-hidden border border-slate-800 bg-slate-950/60 shadow-lg group">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-0 items-center">
              <div className="md:col-span-4 relative h-36 md:h-40 overflow-hidden">
                <img
                  src={finalScore.percentage >= 60 ? studyFutureGoalsImg : deepFocusNightImg}
                  alt={finalScore.percentage >= 60 ? 'Build Your Future' : 'Deep Study Focus'}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent md:bg-gradient-to-r md:from-transparent md:to-slate-950" />
                <div className="absolute bottom-2.5 left-3">
                  <span className={`text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider ${
                    finalScore.percentage >= 80
                      ? 'bg-emerald-400 text-slate-950'
                      : finalScore.percentage >= 60
                      ? 'bg-indigo-400 text-slate-950'
                      : 'bg-amber-400 text-slate-950'
                  }`}>
                    {finalScore.percentage >= 80 ? 'Mastery Reward Earned' : finalScore.percentage >= 60 ? 'Partial Pass Unlocked' : 'Study Desk Mode Active'}
                  </span>
                </div>
              </div>
              <div className="md:col-span-8 p-5 space-y-1.5">
                <h4 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  {finalScore.percentage >= 80
                    ? '“Your Free Time Can Build Your Future”'
                    : finalScore.percentage >= 60
                    ? 'Solid Progress Towards Academic Goals'
                    : 'Turn Setbacks Into Stepping Stones'}
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {finalScore.percentage >= 80
                    ? `By maintaining focus and scoring ${finalScore.percentage}%, you unlocked guilt-free recreation without derailing your exam preparation timeline!`
                    : finalScore.percentage >= 60
                    ? `You've unlocked 15 minutes of recreation. Scoring ≥ 80% on the next attempt will double your earned screen time to 30 minutes.`
                    : `Don't worry—exam preparation is a progression. Use the detailed answer keys below and consult Socrates-AI to turn this weak area into a mastered topic.`}
                </p>
              </div>
            </div>
          </div>

          {/* Question Explanations Breakdown */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-indigo-400" />
              Detailed Exam Solutions & Explanations ({questions.length})
            </h4>

            <div className="space-y-3">
              {questions.map((q, idx) => {
                const userChoice = selectedAnswers[q.id];
                const isCorrect = userChoice === q.correctIndex;

                return (
                  <div
                    key={q.id}
                    className={`p-4 rounded-xl border text-xs sm:text-sm ${
                      isCorrect
                        ? 'bg-emerald-500/5 border-emerald-500/30'
                        : 'bg-rose-500/5 border-rose-500/30'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h5 className="font-bold text-white">
                        {idx + 1}. {q.question}
                      </h5>
                      {isCorrect ? (
                        <span className="text-emerald-400 font-bold flex items-center gap-1 shrink-0 text-xs">
                          <CheckCircle2 className="w-4 h-4" /> Correct
                        </span>
                      ) : (
                        <span className="text-rose-400 font-bold flex items-center gap-1 shrink-0 text-xs">
                          <XCircle className="w-4 h-4" /> Incorrect
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 my-2 text-xs">
                      {q.options.map((opt, oIdx) => (
                        <div
                          key={oIdx}
                          className={`p-2 rounded-lg border ${
                            oIdx === q.correctIndex
                              ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-200 font-semibold'
                              : oIdx === userChoice
                              ? 'bg-rose-500/20 border-rose-500/40 text-rose-200 font-semibold'
                              : 'bg-slate-800/40 border-slate-700/60 text-slate-400'
                          }`}
                        >
                          <span className="font-bold mr-1.5">
                            {String.fromCharCode(65 + oIdx)}.
                          </span>
                          {opt}
                        </div>
                      ))}
                    </div>

                    <div className="mt-2 text-xs text-slate-300 bg-slate-800/60 p-2.5 rounded-lg">
                      <strong className="text-indigo-300 font-semibold">Explanation: </strong>
                      {q.explanation}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Action Footer */}
          <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              onClick={() => onNavigateToTutor(selectedSubject, selectedTopic)}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4" />
              Discuss missed questions with AI Study Tutor
            </button>

            <button
              onClick={() => {
                setQuizFinished(false);
                setIsQuizActive(false);
              }}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all flex items-center gap-2 shadow-md shadow-indigo-600/20"
            >
              <RotateCcw className="w-4 h-4" />
              Take Another Quiz
            </button>
          </div>
        </div>
      )}

      {/* 4. ABANDON QUIZ CONFIRMATION MODAL (Enforcing 30-Minute Penalty) */}
      {showAbandonModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-900 border border-rose-500/50 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto">
              <Lock className="w-6 h-6 animate-pulse" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-lg font-bold text-white">
                Abandon Quiz & Incur 30-Minute Penalty?
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Under the strict <strong>Exam Focus</strong> policy, students cannot leave an active test in the middle.
                If you exit now, a <strong>30-Minute Penalty Lockout</strong> will immediately lock all entertainment
                apps (Instagram, YouTube, etc.) with 0 minutes earned.
              </p>
            </div>

            {/* Deep Focus Desk Visual */}
            <div className="relative rounded-xl overflow-hidden border border-rose-500/30">
              <img
                src={deepFocusNightImg}
                alt="Focused Study Desk"
                referrerPolicy="no-referrer"
                className="w-full h-28 object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />
              <div className="absolute bottom-2 left-2.5 right-2.5 text-left">
                <p className="text-[11px] font-bold text-white">
                  Stay in the zone! Clear this quiz to earn your guilt-free break.
                </p>
              </div>
            </div>

            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-center text-xs font-semibold text-rose-300">
              ⚠️ Penalty: 30 Minutes of Zero Social Media / Video Access
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setShowAbandonModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-colors"
              >
                Continue Quiz
              </button>

              <button
                id="confirm-abandon-penalty-btn"
                onClick={() => handleAbandonConfirmed()}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-md shadow-rose-600/30"
              >
                Abandon (Accept Penalty)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
