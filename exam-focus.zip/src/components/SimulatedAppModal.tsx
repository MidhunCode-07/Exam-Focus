import React from 'react';
import {
  X,
  Lock,
  Unlock,
  Clock,
  AlertTriangle,
  Sparkles,
  ArrowRight,
  ThumbsUp,
  Heart,
  Share2,
  Play,
  RotateCcw,
  Zap,
} from 'lucide-react';
import { DistractingApp, ScreenTimePass, PenaltyState, ExamItem } from '../types';
import { deepFocusNightImg } from '../assets/images';

interface SimulatedAppModalProps {
  app: DistractingApp | null;
  onClose: () => void;
  screenTimePass: ScreenTimePass;
  penaltyState: PenaltyState;
  onNavigateToQuiz: () => void;
  onEndBreakEarly: () => void;
  nearestExam: ExamItem | null;
}

export const SimulatedAppModal: React.FC<SimulatedAppModalProps> = ({
  app,
  onClose,
  screenTimePass,
  penaltyState,
  onNavigateToQuiz,
  onEndBreakEarly,
  nearestExam,
}) => {
  if (!app) return null;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const isPenaltyLocked = penaltyState.active;
  const isPassUnlocked = screenTimePass.active && screenTimePass.remainingSeconds > 0 && !isPenaltyLocked;
  const isDefaultBlocked = app.blocked && !isPassUnlocked;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Modal Window Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`w-7 h-7 rounded-lg bg-gradient-to-tr ${app.color} flex items-center justify-center text-white text-xs font-bold`}>
              {app.name[0]}
            </div>
            <div>
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                {app.name} Simulation
                {isPenaltyLocked ? (
                  <span className="text-[10px] bg-rose-500/20 text-rose-300 border border-rose-500/30 px-1.5 py-0.2 rounded font-semibold">
                    Penalty Lock
                  </span>
                ) : isPassUnlocked ? (
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.2 rounded font-semibold">
                    Pass Active
                  </span>
                ) : (
                  <span className="text-[10px] bg-slate-800 text-slate-400 border border-slate-700 px-1.5 py-0.2 rounded font-semibold">
                    Exam Shield Blocked
                  </span>
                )}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content Body based on state */}
        <div className="flex-1 overflow-y-auto p-6 text-center">
          {/* STATE 1: PENALTY LOCKOUT (Active 30 min penalty) */}
          {isPenaltyLocked && (
            <div className="space-y-5 py-4">
              <div className="w-20 h-20 rounded-3xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto animate-pulse shadow-lg shadow-rose-500/10">
                <AlertTriangle className="w-10 h-10" />
              </div>

              <div className="space-y-2">
                <span className="text-[11px] uppercase tracking-widest font-black text-rose-400">
                  Strict Examination Protocol Enforced
                </span>
                <h3 className="text-xl font-bold text-white tracking-tight">
                  30-Minute Penalty Lockdown
                </h3>
                <p className="text-xs text-slate-300 max-w-sm mx-auto leading-relaxed">
                  You abandoned an ongoing exam focus quiz session early. To preserve academic stamina, all entertainment
                  and social apps are locked down for 30 minutes.
                </p>
              </div>

              {/* Countdown box */}
              <div className="bg-slate-950 border border-rose-500/30 rounded-2xl p-4 max-w-xs mx-auto">
                <span className="text-xs text-slate-400 font-semibold block mb-1">
                  Penalty Lockout Remaining:
                </span>
                <span className="text-3xl font-mono font-black text-rose-400 tracking-wider">
                  {formatTime(penaltyState.remainingSeconds)}
                </span>
              </div>

              <div className="p-3 bg-slate-800/60 rounded-xl text-xs text-slate-400 max-w-sm mx-auto">
                💡 <em>"Discipline is choosing between what you want now and what you want most."</em>
              </div>

              <button
                onClick={onClose}
                className="w-full max-w-xs mx-auto py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all block"
              >
                Acknowledge & Return to Studies
              </button>
            </div>
          )}

          {/* STATE 2: BLOCKED BY EXAM SHIELD (No pass earned yet) */}
          {!isPenaltyLocked && isDefaultBlocked && (
            <div className="space-y-5 py-4">
              <div className="w-20 h-20 rounded-3xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 flex items-center justify-center mx-auto shadow-lg shadow-indigo-500/10">
                <Lock className="w-10 h-10" />
              </div>

              <div className="space-y-2">
                <span className="text-[11px] uppercase tracking-widest font-black text-indigo-400">
                  Exam Focus Shield Active
                </span>
                <h3 className="text-xl font-bold text-white tracking-tight">
                  {app.name} is Locked During Exam Period
                </h3>
                <p className="text-xs text-slate-300 max-w-sm mx-auto leading-relaxed">
                  Under your active study schedule, distracting social media and video apps remain locked until you earn
                  screen time.
                </p>
              </div>

              {/* Deep Focus Desk Visual Reminder */}
              <div className="relative rounded-2xl overflow-hidden border border-indigo-500/30 max-w-sm mx-auto shadow-xl group">
                <img
                  src={deepFocusNightImg}
                  alt="Deep Study Focus Desk"
                  referrerPolicy="no-referrer"
                  className="w-full h-36 object-cover object-center group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />
                <div className="absolute bottom-2.5 left-3 right-3 text-left">
                  <span className="text-[9px] font-black text-amber-300 bg-amber-500/20 px-1.5 py-0.5 rounded border border-amber-500/30 uppercase tracking-wider">
                    Deep Study Mode Engaged
                  </span>
                  <p className="text-xs font-bold text-white mt-1">
                    Your focus desk is active. Clear your exam topics first!
                  </p>
                </div>
              </div>

              {/* Upcoming exam callout */}
              {nearestExam && (
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 max-w-sm mx-auto text-left flex items-center justify-between gap-3">
                  <div>
                    <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider block">
                      Target Exam:
                    </span>
                    <h5 className="text-xs font-bold text-white">{nearestExam.subject}</h5>
                    <span className="text-[10px] text-slate-400">Date: {nearestExam.date}</span>
                  </div>
                  <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-2 py-1 rounded border border-amber-500/20">
                    High Priority
                  </span>
                </div>
              )}

              {/* Positive Reinforcement Call to Action */}
              <div className="p-4 bg-gradient-to-br from-indigo-950/60 to-purple-950/60 border border-indigo-500/30 rounded-2xl max-w-sm mx-auto space-y-3">
                <div className="flex items-center justify-center gap-2 text-indigo-300 text-xs font-bold">
                  <Sparkles className="w-4 h-4 text-indigo-400" />
                  Positive Reinforcement Rule:
                </div>
                <p className="text-xs text-slate-300">
                  Complete a 5-question readiness quiz and score <strong>80% or higher</strong> to unlock
                  <strong> 15 to 30 minutes of real screen time</strong> on {app.name}!
                </p>

                <button
                  id="unlock-via-quiz-btn"
                  onClick={() => {
                    onClose();
                    onNavigateToQuiz();
                  }}
                  className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-indigo-600/30 flex items-center justify-center gap-2"
                >
                  <span>Take Quiz to Unlock Pass</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STATE 3: UNLOCKED VIA EARNED SCREEN TIME PASS */}
          {!isPenaltyLocked && isPassUnlocked && (
            <div className="space-y-4 text-left">
              {/* Top timer bar */}
              <div className="bg-emerald-500/20 border border-emerald-500/40 rounded-xl p-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/30 flex items-center justify-center text-emerald-300">
                    <Clock className="w-4 h-4 animate-spin" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-emerald-200 block">
                      Screen Time Pass Active:
                    </span>
                    <span className="text-[10px] text-emerald-300/80">
                      Earned via verified quiz score &ge; 80%
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xl font-mono font-black text-emerald-300">
                    {formatTime(screenTimePass.remainingSeconds)}
                  </span>
                </div>
              </div>

              {/* Realistic Simulated App Interface */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden">
                {/* Simulated App Header */}
                <div className="bg-slate-900 px-4 py-2 border-b border-slate-800 flex items-center justify-between text-xs">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <div className={`w-4 h-4 rounded-full bg-gradient-to-tr ${app.color}`} />
                    {app.name} Feed (Screen Time Sandbox)
                  </span>
                  <span className="text-[10px] text-slate-400">Live Active Pass</span>
                </div>

                {/* Simulated Content items based on app */}
                {app.id === 'youtube' ? (
                  <div className="p-4 space-y-3">
                    <div className="aspect-video bg-slate-900 rounded-xl border border-slate-800 flex flex-col items-center justify-center text-center p-4 relative overflow-hidden group">
                      <div className="w-12 h-12 rounded-full bg-red-600/90 text-white flex items-center justify-center mb-2 shadow-lg">
                        <Play className="w-6 h-6 ml-0.5" />
                      </div>
                      <h5 className="text-xs font-bold text-white">
                        Relaxing Lo-Fi Study Chill Beats & Nature Break
                      </h5>
                      <p className="text-[10px] text-slate-400 mt-1">
                        Enjoy your earned break! The screen lock will automatically re-engage when time expires.
                      </p>
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                      <span className="flex items-center gap-1">
                        <ThumbsUp className="w-3.5 h-3.5 text-indigo-400" /> 14.2K Likes
                      </span>
                      <span className="flex items-center gap-1">
                        <Share2 className="w-3.5 h-3.5" /> Share
                      </span>
                    </div>
                  </div>
                ) : app.id === 'instagram' ? (
                  <div className="p-4 space-y-3">
                    <div className="bg-slate-900 rounded-xl p-3 border border-slate-800 space-y-2">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-pink-500 flex items-center justify-center text-[10px] font-bold text-white">
                          S
                        </div>
                        <span className="text-xs font-bold text-white">study_motivation_daily</span>
                      </div>
                      <div className="h-36 bg-gradient-to-tr from-slate-900 to-indigo-950 rounded-lg flex items-center justify-center text-center p-3 border border-slate-800">
                        <p className="text-xs font-semibold text-indigo-200">
                          "Success in exams doesn't come from what you do occasionally, it comes from what you do consistently."
                        </p>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-slate-400 pt-1">
                        <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
                        <span className="text-[11px]">Liked by you and 2,491 others</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 space-y-3">
                    <div className="bg-slate-900 rounded-xl p-3 border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-indigo-400">r/StudentMastery</span>
                        <span className="text-[10px] text-slate-500">2h ago</span>
                      </div>
                      <h5 className="text-xs font-bold text-white">
                        How active recall & earning 30m gaming breaks helped me ace my semester finals!
                      </h5>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        Never cram 8 hours straight. Using positive reinforcement transformed my study stamina.
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Early return incentive */}
              <div className="pt-2 flex items-center justify-between gap-3">
                <button
                  onClick={onEndBreakEarly}
                  className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
                >
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  <span>End Break Early (+50 Bonus XP)</span>
                </button>

                <button
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all"
                >
                  Keep Browsing
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
