import React, { useState } from 'react';
import {
  Sparkles,
  Calendar,
  Clock,
  BookOpen,
  CheckCircle2,
  AlertTriangle,
  Zap,
  TrendingUp,
  RefreshCw,
  ArrowRight,
  Target,
  Sliders,
  Award,
} from 'lucide-react';
import {
  AcademicField,
  ExamItem,
  PersonalizedStudyPlan,
  StudentPerformanceProfile,
} from '../types';
import { gradLightbulbLadderImg } from '../assets/images';

interface AIStudyPlanViewProps {
  currentField: AcademicField;
  exams: ExamItem[];
  performanceProfile: StudentPerformanceProfile;
  studyPlan: PersonalizedStudyPlan | null;
  setStudyPlan: (plan: PersonalizedStudyPlan) => void;
  onNavigateToQuiz: (subject: string, topic: string) => void;
  onNavigateToTutor: (subject: string, topic: string) => void;
  isQuizActive: boolean;
}

export const AIStudyPlanView: React.FC<AIStudyPlanViewProps> = ({
  currentField,
  exams,
  performanceProfile,
  studyPlan,
  setStudyPlan,
  onNavigateToQuiz,
  onNavigateToTutor,
  isQuizActive,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedPlanDay, setSelectedPlanDay] = useState(1);
  const [daysCount, setDaysCount] = useState<number>(5);
  const [dailyHours, setDailyHours] = useState<number>(4);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleGeneratePlan = async () => {
    setIsGenerating(true);
    setErrorMsg(null);

    try {
      const response = await fetch('/api/study/plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          academicField: currentField,
          exams,
          performanceProfile,
          availableDays: daysCount,
          dailyHours,
        }),
      });

      if (!response.ok) {
        throw new Error('Server error generating personalized study plan');
      }

      const data = await response.json();
      if (data.plan) {
        setStudyPlan(data.plan);
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg('Could not fetch AI plan from server. Using intelligent local synthesis.');
      // Local fallback generation
      synthesizeLocalPlan();
    } finally {
      setIsGenerating(false);
    }
  };

  const synthesizeLocalPlan = () => {
    const activeExams = exams.length > 0 ? exams : [];
    const synthesizedDays = Array.from({ length: daysCount }).map((_, i) => {
      const dayNum = i + 1;
      const targetExam = activeExams[i % activeExams.length];
      const targetSubject = targetExam?.subject || 'Engineering & Science Core';
      const topics = targetExam?.syllabusTopics || ['Fundamental Principles', 'Problem Sets'];

      return {
        dayNumber: dayNum,
        date: new Date(Date.now() + i * 86400000).toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
        }),
        focusGoal: `Master high-yield concepts in ${targetSubject}`,
        tasks: [
          {
            id: `task-${dayNum}-1`,
            title: `Concept Synthesis & Review: ${topics[0] || 'Core Theory'}`,
            subject: targetSubject,
            topic: topics[0] || 'Core Theory',
            timeSlot: '08:00 AM - 09:30 AM',
            durationMinutes: 90,
            type: 'concept_review' as const,
            completed: false,
            priority: 'High' as const,
            reasonForInclusion: 'Upcoming scheduled exam in your uploaded timetable.',
          },
          {
            id: `task-${dayNum}-2`,
            title: `Remediation Drill: ${performanceProfile.weakTopics[0] || 'Identified Weak Areas'}`,
            subject: targetSubject,
            topic: performanceProfile.weakTopics[0] || topics[1] || 'Difficult Mechanics',
            timeSlot: '11:00 AM - 12:30 PM',
            durationMinutes: 90,
            type: 'formula_drill' as const,
            completed: false,
            priority: 'High' as const,
            reasonForInclusion:
              'Automated weakness intervention based on past quiz score < 70%.',
          },
          {
            id: `task-${dayNum}-3`,
            title: `Timed Quiz & Screen Time Reward Run`,
            subject: targetSubject,
            topic: topics[0] || 'Mastery Set',
            timeSlot: '03:00 PM - 03:45 PM',
            durationMinutes: 45,
            type: 'practice_quiz' as const,
            completed: false,
            priority: 'Medium' as const,
            reasonForInclusion: 'Score 80%+ to unlock 30m social media break.',
          },
        ],
      };
    });

    setStudyPlan({
      id: `plan-${Date.now()}`,
      title: `${currentField} Adaptive Exam Success Plan`,
      generatedAt: new Date().toISOString(),
      studentField: currentField,
      totalDays: daysCount,
      strategySummary: `This personalized study plan integrates your uploaded timetable with quiz diagnostics. Weak areas receive prioritized remediation blocks before moving to high-weightage topics.`,
      weakTopicsTargeted: performanceProfile.weakTopics,
      days: synthesizedDays,
    });
  };

  const currentDayData =
    studyPlan?.days.find((d) => d.dayNumber === selectedPlanDay) || studyPlan?.days[0];

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* 1. TOP HERO: Personalized Study Plan Generator with Graduation Ladder Visual */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
          {/* Left / Info & Controls (5 cols) */}
          <div className="lg:col-span-5 p-6 flex flex-col justify-between space-y-4">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                Gemini 3.8 Multi-Factor Study Planner
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                Personalized Adaptive Study Plan
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Our AI analyzes your <strong>uploaded exam timetable</strong>, upcoming test deadlines,
                and <strong>quiz performance history</strong> to generate a customized, day-by-day
                study schedule. Weak topics are automatically scheduled for targeted drill sessions.
              </p>
            </div>

            {/* Quick Config & Action */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-white">
                <span className="flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-indigo-400" /> Plan Parameters
                </span>
                <span className="text-[10px] text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                  Adaptive
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Duration</label>
                  <select
                    value={daysCount}
                    onChange={(e) => setDaysCount(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 text-xs font-semibold focus:outline-none"
                  >
                    <option value={3}>3 Days</option>
                    <option value={5}>5 Days</option>
                    <option value={7}>7 Days (1 Week)</option>
                    <option value={14}>14 Days (2 Weeks)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Daily Study</label>
                  <select
                    value={dailyHours}
                    onChange={(e) => setDailyHours(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 text-xs font-semibold focus:outline-none"
                  >
                    <option value={3}>3 Hours/Day</option>
                    <option value={4}>4 Hours/Day</option>
                    <option value={6}>6 Hours/Day</option>
                  </select>
                </div>
              </div>

              <button
                id="generate-ai-study-plan-btn"
                onClick={handleGeneratePlan}
                disabled={isGenerating}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-bold transition-all shadow-md shadow-indigo-600/25 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Generating Plan with Gemini...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Generate / Update AI Study Plan
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right / Visual Showcase (7 cols) */}
          <div className="lg:col-span-7 relative min-h-[260px] overflow-hidden group bg-slate-950 flex items-center justify-center border-t lg:border-t-0 lg:border-l border-slate-800">
            <img
              src={gradLightbulbLadderImg}
              alt="The Ladder to Graduation & Knowledge Mastery"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 max-h-[340px]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent" />
            <div className="absolute bottom-4 left-5 right-5 z-10 flex flex-col sm:flex-row sm:items-end justify-between gap-2">
              <div>
                <span className="inline-block px-2 py-0.5 rounded-md bg-amber-400 text-slate-950 text-[10px] font-black uppercase tracking-wider mb-1 shadow">
                  Milestone Vision
                </span>
                <h3 className="text-base sm:text-lg font-black text-white drop-shadow-md">
                  Climb the Knowledge Ladder to Graduation
                </h3>
                <p className="text-xs text-slate-300 drop-shadow">
                  Each completed quiz step illuminates your pathway to top exam scores.
                </p>
              </div>
              <div className="shrink-0 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-amber-500/30 text-amber-300 text-xs font-mono font-bold">
                {performanceProfile.averageScore}% Avg Mastery
              </div>
            </div>
          </div>
        </div>

        {errorMsg && (
          <div className="m-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
            {errorMsg}
          </div>
        )}
      </div>

      {/* 2. DIAGNOSTIC PERFORMANCE INSIGHTS (Strengths vs Weaknesses) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Identified Weak Topics */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-rose-400 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" /> Targeted Weak Topics (&lt; 70%)
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              {performanceProfile.weakTopics.length} detected
            </span>
          </div>
          <div className="flex flex-wrap gap-1.5 pt-1">
            {performanceProfile.weakTopics.length > 0 ? (
              performanceProfile.weakTopics.map((topic, i) => (
                <span
                  key={i}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 font-medium"
                >
                  • {topic}
                </span>
              ))
            ) : (
              <span className="text-xs text-slate-400 italic">No critical weaknesses detected!</span>
            )}
          </div>
          <p className="text-[10px] text-slate-400 pt-1">
            Scheduled for prioritized foundational drills in your daily calendar.
          </p>
        </div>

        {/* Mastered Topics */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-emerald-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" /> Mastered Topics (&ge; 80%)
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              {performanceProfile.masteredTopics.length} mastered
            </span>
          </div>
          <div className="flex flex-wrap gap-1.5 pt-1">
            {performanceProfile.masteredTopics.length > 0 ? (
              performanceProfile.masteredTopics.map((topic, i) => (
                <span
                  key={i}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-medium"
                >
                  ✓ {topic}
                </span>
              ))
            ) : (
              <span className="text-xs text-slate-400 italic">Complete quizzes to unlock masteries.</span>
            )}
          </div>
          <p className="text-[10px] text-slate-400 pt-1">
            Maintained via periodic rapid active-recall reviews.
          </p>
        </div>

        {/* Exam Timeline Integration */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-indigo-400 flex items-center gap-1.5">
              <Calendar className="w-4 h-4" /> Upcoming Exam Deadlines
            </span>
            <span className="text-[10px] text-slate-400 font-mono">{exams.length} scheduled</span>
          </div>
          <div className="space-y-1 text-xs">
            {exams.slice(0, 2).map((e) => (
              <div key={e.id} className="flex items-center justify-between py-0.5">
                <span className="text-white truncate max-w-[150px] font-medium">{e.subject}</span>
                <span className="text-[11px] text-amber-300 font-bold">{e.date}</span>
              </div>
            ))}
          </div>
          <p className="text-[10px] text-slate-400 pt-1">
            High priority subjects receive greater study block density.
          </p>
        </div>
      </div>

      {/* 3. ACTIVE PLAN DETAILS & DAY SELECTOR */}
      {studyPlan && studyPlan.days.length > 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
          {/* Strategy Statement */}
          <div className="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-200 flex items-start gap-3">
            <Target className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-white mb-1">
                {studyPlan.title} &bull; Strategy Blueprint
              </h4>
              <p className="leading-relaxed text-indigo-200/90">{studyPlan.strategySummary}</p>
            </div>
          </div>

          {/* Days Tabs (Day 1, Day 2, Day 3...) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-800">
            {studyPlan.days.map((d, idx) => {
              const dayNum = d.dayNumber ?? idx + 1;
              return (
                <button
                  key={dayNum}
                  onClick={() => setSelectedPlanDay(dayNum)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 ${
                    selectedPlanDay === dayNum
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                      : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
                  }`}
                >
                  <span>Day {dayNum}</span>
                  <span className="text-[10px] opacity-75">({d.date})</span>
                </button>
              );
            })}
          </div>

          {/* Selected Day's Task Breakdown */}
          {currentDayData && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div>
                  <h3 className="text-base font-bold text-white">
                    Day {currentDayData.dayNumber}: {currentDayData.focusGoal}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Target tasks calibrated to prevent cognitive fatigue and ensure quiz readiness.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {currentDayData.tasks.map((task, idx) => {
                  const isRemediation =
                    task.type === 'formula_drill' || task.title.toLowerCase().includes('remediation');
                  const isQuiz = task.type === 'practice_quiz';

                  return (
                    <div
                      key={task.id || idx}
                      className={`p-4 rounded-xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                        isRemediation
                          ? 'bg-amber-500/5 border-amber-500/30'
                          : isQuiz
                          ? 'bg-indigo-500/5 border-indigo-500/30'
                          : 'bg-slate-800/50 border-slate-700/70'
                      }`}
                    >
                      <div className="flex items-start gap-3.5">
                        <div
                          className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                            isRemediation
                              ? 'bg-amber-500/20 text-amber-300'
                              : isQuiz
                              ? 'bg-indigo-500/20 text-indigo-300'
                              : 'bg-emerald-500/20 text-emerald-300'
                          }`}
                        >
                          {isRemediation ? (
                            <AlertTriangle className="w-5 h-5" />
                          ) : isQuiz ? (
                            <Zap className="w-5 h-5" />
                          ) : (
                            <BookOpen className="w-5 h-5" />
                          )}
                        </div>

                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <h4 className="text-xs sm:text-sm font-bold text-white">
                              {task.title}
                            </h4>
                            {isRemediation && (
                              <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded font-semibold">
                                Weakness Remediation
                              </span>
                            )}
                            {isQuiz && (
                              <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded font-semibold">
                                Score &ge; 80% to Unlock Screen Pass
                              </span>
                            )}
                          </div>

                          <p className="text-xs text-slate-300">
                            Subject: <strong className="text-white">{task.subject}</strong> &bull; Topic:{' '}
                            <span className="text-indigo-300">{task.topic}</span>
                          </p>

                          <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400 pt-0.5">
                            <span className="flex items-center gap-1 font-mono text-slate-300">
                              <Clock className="w-3.5 h-3.5 text-slate-500" />
                              {task.timeSlot}
                            </span>
                            <span>&bull; {task.durationMinutes} minutes</span>
                            {task.reasonForInclusion && (
                              <span className="text-slate-400 italic">
                                &bull; {task.reasonForInclusion}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Action trigger buttons */}
                      <div className="shrink-0 flex items-center gap-2">
                        {isQuiz ? (
                          <button
                            onClick={() => onNavigateToQuiz(task.subject, task.topic)}
                            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-indigo-600/25 flex items-center gap-1.5"
                          >
                            <Zap className="w-3.5 h-3.5" />
                            <span>Launch Quiz</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => onNavigateToTutor(task.subject, task.topic)}
                            disabled={isQuizActive}
                            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all flex items-center gap-1.5 disabled:opacity-40"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                            <span>Study with AI Tutor</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400 space-y-3 shadow-md">
          <Calendar className="w-10 h-10 mx-auto text-indigo-400" />
          <h3 className="text-base font-bold text-white">No Active AI Study Plan Yet</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Click "Generate AI Study Plan" above to create an optimized schedule based on your timetable
            and quiz scores!
          </p>
          <button
            onClick={handleGeneratePlan}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/25"
          >
            Generate My Personalized Plan
          </button>
        </div>
      )}
    </div>
  );
};
