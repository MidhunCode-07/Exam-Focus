import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Sparkles,
  Bot,
  User,
  Lightbulb,
  BookOpen,
  FileSpreadsheet,
  BrainCircuit,
  Lock,
  RotateCcw,
  Zap,
} from 'lucide-react';
import { AcademicField, ChatMessage, ExamItem, StudentPerformanceProfile } from '../types';
import { deepFocusNightImg } from '../assets/images';

interface AIStudyTutorProps {
  currentField: AcademicField;
  selectedExam: ExamItem | null;
  selectedTopic: string;
  isQuizActive: boolean;
  onLaunchQuizForTopic: (subject: string, topic: string) => void;
  performanceProfile?: StudentPerformanceProfile;
  onNavigateToStudyPlan?: () => void;
}

export const AIStudyTutor: React.FC<AIStudyTutorProps> = ({
  currentField,
  selectedExam,
  selectedTopic,
  isQuizActive,
  onLaunchQuizForTopic,
  performanceProfile,
  onNavigateToStudyPlan,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      role: 'assistant',
      text: `Hello! I am your **Exam Focus AI Study Tutor**.
I'm here to clarify doubts, generate high-yield revision summaries, mnemonics, and formula cheat sheets across **${currentField}**.

${selectedExam ? `Currently focused on: **${selectedExam.subject}** (${selectedTopic || 'General Syllabus'})` : 'Select any subject from your timetable, or ask any concept question below.'}

*Remember:* When you feel confident, take a topic quiz! Scoring **80% or above** unlocks **15 to 30 minutes of real screen time** on your entertainment apps!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const activeSubject = selectedExam ? selectedExam.subject : 'General Sciences & Mathematics';
  const activeTopic = selectedTopic || (selectedExam ? selectedExam.syllabusTopics[0] : 'Foundational Principles');

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    if (isQuizActive) return; // STRICT RULE: Chatbot stopped during quiz
    const msg = textToSend || inputMessage;
    if (!msg.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: msg,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      topic: activeTopic,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/study/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: msg,
          history: messages.slice(-6).map((m) => ({ role: m.role, text: m.text })),
          academicField: currentField,
          subject: activeSubject,
          topic: activeTopic,
        }),
      });

      if (!response.ok) {
        throw new Error('Chat API returned an error');
      }

      const data = await response.json();
      const botMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        text: data.reply || 'Here is your exam study guidance.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err: any) {
      console.error(err);
      const fallbackMsg: ChatMessage = {
        id: `ai-err-${Date.now()}`,
        role: 'assistant',
        text: `### Exam Study Notes: ${activeTopic}\n\n` +
          `• **Core Definition**: Focus on the highest-weightage exam questions and key terminology.\n` +
          `• **Formula / Principle**: Step 1: Identify given variables. Step 2: Formulate boundary conditions. Step 3: Compute with units.\n` +
          `• **Exam Tip**: In long-form questions, always draw neat diagrams and list key bullet points.\n\n` +
          `Ready to verify your retention? Start the quiz now to unlock your screen time!`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickPrompt = (promptType: string) => {
    if (isQuizActive) return;
    let query = '';
    switch (promptType) {
      case 'summary':
        query = `Provide a 3-minute high-yield exam summary for ${activeTopic} in ${activeSubject} with key definitions and common examiner traps.`;
        break;
      case 'mnemonics':
        query = `Give me clever mnemonics and memory devices to easily recall the core concepts in ${activeTopic} during the exam.`;
        break;
      case 'formulas':
        query = `Create a bulleted formula sheet, cheat sheet, and essential rules for ${activeTopic} in ${activeSubject}.`;
        break;
      case 'questions':
        query = `What are the top 5 most frequently repeated exam questions and high-probability problem types for ${activeTopic}?`;
        break;
      case 'analogy':
        query = `Explain ${activeTopic} like I am 5 years old using an intuitive real-world analogy.`;
        break;
      default:
        query = `Explain ${activeTopic} clearly for my exam.`;
    }
    handleSendMessage(query);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl flex flex-col h-[700px] overflow-hidden shadow-xl relative">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 bg-slate-900/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white">Socrates-AI Study Assistant</h3>
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-500/30 font-semibold">
                {currentField.split(' ')[0]}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Target: <strong className="text-slate-200">{activeSubject}</strong> &bull;{' '}
              <span className="text-indigo-300">{activeTopic}</span>
            </p>
          </div>
        </div>

        {/* Action: Jump to quiz */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onLaunchQuizForTopic(activeSubject, activeTopic)}
            className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm"
          >
            <Zap className="w-3.5 h-3.5" />
            Quiz On This Topic
          </button>

          <button
            onClick={() =>
              setMessages([
                {
                  id: `reset-${Date.now()}`,
                  role: 'assistant',
                  text: `Chat refreshed. Ask me anything about **${activeSubject}**!`,
                  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                },
              ])
            }
            title="Clear chat history"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* QUICK PROMPT CHIPS (Disabled during active quiz) */}
      {!isQuizActive && (
        <div className="px-4 py-2 border-b border-slate-800 bg-slate-800/40 flex items-center gap-2 overflow-x-auto text-xs scrollbar-none">
          <span className="text-slate-400 text-[11px] font-semibold flex items-center gap-1 shrink-0">
            <Sparkles className="w-3 h-3 text-indigo-400" />
            Instant Prompts:
          </span>

          <button
            onClick={() => handleQuickPrompt('summary')}
            className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-indigo-900/40 text-slate-300 hover:text-indigo-200 border border-slate-700 text-[11px] font-medium whitespace-nowrap transition-colors flex items-center gap-1 shrink-0"
          >
            <BookOpen className="w-3 h-3 text-indigo-400" /> 3-Min Summary
          </button>

          <button
            onClick={() => handleQuickPrompt('mnemonics')}
            className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-indigo-900/40 text-slate-300 hover:text-indigo-200 border border-slate-700 text-[11px] font-medium whitespace-nowrap transition-colors flex items-center gap-1 shrink-0"
          >
            <BrainCircuit className="w-3 h-3 text-purple-400" /> Memory Mnemonics
          </button>

          <button
            onClick={() => handleQuickPrompt('formulas')}
            className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-indigo-900/40 text-slate-300 hover:text-indigo-200 border border-slate-700 text-[11px] font-medium whitespace-nowrap transition-colors flex items-center gap-1 shrink-0"
          >
            <FileSpreadsheet className="w-3 h-3 text-emerald-400" /> Formula Sheet
          </button>

          <button
            onClick={() => handleQuickPrompt('questions')}
            className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-indigo-900/40 text-slate-300 hover:text-indigo-200 border border-slate-700 text-[11px] font-medium whitespace-nowrap transition-colors flex items-center gap-1 shrink-0"
          >
            <Lightbulb className="w-3 h-3 text-amber-400" /> Top 5 Repeated Questions
          </button>

          <button
            onClick={() => handleQuickPrompt('analogy')}
            className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-indigo-900/40 text-slate-300 hover:text-indigo-200 border border-slate-700 text-[11px] font-medium whitespace-nowrap transition-colors flex items-center gap-1 shrink-0"
          >
            <Sparkles className="w-3 h-3 text-pink-400" /> Simple Analogy
          </button>

          {performanceProfile?.weakTopics && performanceProfile.weakTopics.length > 0 && (
            <button
              onClick={() => {
                const weak = performanceProfile.weakTopics[0];
                handleSendMessage(`Explain the core mechanics and common pitfalls of my identified weak topic: "${weak}". Provide a step-by-step memory model.`);
              }}
              className="px-2.5 py-1 rounded-full bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-[11px] font-medium whitespace-nowrap transition-colors flex items-center gap-1 shrink-0"
            >
              <Lightbulb className="w-3 h-3 text-rose-400" /> Drill Weak Area: {performanceProfile.weakTopics[0]}
            </button>
          )}

          {onNavigateToStudyPlan && (
            <button
              onClick={onNavigateToStudyPlan}
              className="px-2.5 py-1 rounded-full bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border border-indigo-500/40 text-[11px] font-medium whitespace-nowrap transition-colors flex items-center gap-1 shrink-0"
            >
              <Sparkles className="w-3 h-3 text-indigo-300" /> AI Study Plan &rarr;
            </button>
          )}
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Deep Focus Desk Sanctuary Visual Card */}
        <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950/60 shadow-lg group">
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-0 items-center">
            <div className="sm:col-span-4 relative h-28 sm:h-32 overflow-hidden">
              <img
                src={deepFocusNightImg}
                alt="Focused Study Desk"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent sm:bg-gradient-to-r sm:from-transparent sm:to-slate-950" />
            </div>
            <div className="sm:col-span-8 p-3.5 space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-[9px] font-black text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30 uppercase tracking-wider">
                  Deep Focus Sanctuary
                </span>
                <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Shield Active
                </span>
              </div>
              <h4 className="text-xs sm:text-sm font-bold text-white">
                Socratic Concept Revision & Memory Mastery
              </h4>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Work through definitions, formulas, and tricky traps with your AI Tutor. When you feel ready,
                test your retention with a 5-question quiz to unlock 15–30m of screen time!
              </p>
            </div>
          </div>
        </div>

        {messages.map((msg) => {
          const isAI = msg.role === 'assistant';

          return (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${isAI ? 'justify-start' : 'justify-end'}`}
            >
              {isAI && (
                <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-300 shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                  isAI
                    ? 'bg-slate-800/90 border border-slate-700/80 text-slate-100 shadow-sm'
                    : 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                }`}
              >
                <div className="whitespace-pre-wrap font-sans">
                  {msg.text}
                </div>

                <div
                  className={`text-[10px] mt-2 flex items-center justify-between ${
                    isAI ? 'text-slate-400' : 'text-indigo-200'
                  }`}
                >
                  <span>{msg.timestamp}</span>
                  {isAI && (
                    <button
                      onClick={() => onLaunchQuizForTopic(activeSubject, activeTopic)}
                      className="text-indigo-400 hover:text-indigo-300 font-semibold underline underline-offset-2 ml-3"
                    >
                      Test this topic &rarr;
                    </button>
                  )}
                </div>
              </div>

              {!isAI && (
                <div className="w-8 h-8 rounded-lg bg-indigo-500 flex items-center justify-center text-white shrink-0 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-300 shrink-0">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 text-xs text-slate-300 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400 animate-spin" />
              <span>Socrates-AI is compiling high-yield exam guidance...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* FOOTER / INPUT AREA */}
      {isQuizActive ? (
        /* CRITICAL REQUIREMENT: "when the quiz starts the chatbot should be stopped and user should not leave the quiz in middle" */
        <div className="p-4 bg-slate-950 border-t border-rose-500/30 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-rose-300">
              🔒 AI Tutor Suspended During Active Quiz
            </h4>
            <p className="text-[11px] text-rose-400/90 leading-tight">
              To guarantee true exam simulation and academic integrity, Socrates-AI is paused while your test is running.
              Complete or submit your quiz to re-enable doubt clarification.
            </p>
          </div>
        </div>
      ) : (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2"
        >
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            disabled={isLoading}
            placeholder={`Ask a doubt or request formulas for ${activeTopic}...`}
            className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
          />

          <button
            type="submit"
            disabled={isLoading || !inputMessage.trim()}
            className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-md shadow-indigo-600/20 shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      )}
    </div>
  );
};
