import React from 'react';
import {
  GraduationCap,
  ShieldCheck,
  ShieldAlert,
  Flame,
  Zap,
  Clock,
  AlertTriangle,
  Sparkles,
} from 'lucide-react';
import { AcademicField, ScreenTimePass, PenaltyState, UserProgress, ActiveNavTab } from '../types';
import { ACADEMIC_FIELDS } from '../data/mockData';

interface HeaderProps {
  currentField: AcademicField;
  onFieldChange: (field: AcademicField) => void;
  screenTimePass: ScreenTimePass;
  penaltyState: PenaltyState;
  userProgress: UserProgress;
  focusModeEnabled: boolean;
  onToggleFocusMode: () => void;
  activeTab: ActiveNavTab;
  setActiveTab: (tab: ActiveNavTab) => void;
  isQuizActive: boolean;
  onToggleMobileMenu?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentField,
  onFieldChange,
  screenTimePass,
  penaltyState,
  userProgress,
  focusModeEnabled,
  onToggleFocusMode,
  activeTab,
  setActiveTab,
  isQuizActive,
  onToggleMobileMenu,
}) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between py-3 gap-3">
          {/* Brand & Field selector */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-500 flex items-center justify-center shadow-lg shadow-indigo-500/25">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-1.5">
                    Exam Focus
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      Study & Earn
                    </span>
                  </h1>
                </div>
                <p className="text-xs text-slate-400">First Study, Then Earn Your Screen Time</p>
              </div>
            </div>

            {/* Mobile focus toggle */}
            <div className="md:hidden">
              <button
                onClick={onToggleFocusMode}
                className={`p-2 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  focusModeEnabled
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                {focusModeEnabled ? 'Shield ON' : 'Shield OFF'}
              </button>
            </div>
          </div>

          {/* Academic Field Selector */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-1 md:pb-0">
            <label htmlFor="academic-field-select" className="text-xs text-slate-400 whitespace-nowrap font-medium flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              Field:
            </label>
            <select
              id="academic-field-select"
              value={currentField}
              onChange={(e) => onFieldChange(e.target.value as AcademicField)}
              disabled={isQuizActive}
              className="bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-lg px-3 py-1.5 font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-colors cursor-pointer"
            >
              {ACADEMIC_FIELDS.map((field) => (
                <option key={field} value={field}>
                  {field}
                </option>
              ))}
            </select>
          </div>

          {/* Live Status Indicators (Pass & Penalty) & Focus toggle */}
          <div className="flex items-center flex-wrap gap-2.5 justify-end">
            {/* 30-min Penalty Indicator if Active */}
            {penaltyState.active && (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-semibold animate-pulse">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>Penalty Lock: {formatTime(penaltyState.remainingSeconds)}</span>
              </div>
            )}

            {/* Screen Time Pass if Active */}
            {screenTimePass.active && !penaltyState.active && (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold">
                <Clock className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Screen Pass: {formatTime(screenTimePass.remainingSeconds)}</span>
              </div>
            )}

            {/* Gamification chips */}
            <div className="hidden sm:flex items-center gap-2 bg-slate-800/80 border border-slate-700/80 px-2.5 py-1.5 rounded-lg text-xs">
              <span className="flex items-center gap-1 text-amber-400 font-bold" title="Study Streak">
                <Flame className="w-3.5 h-3.5 fill-amber-400" />
                {userProgress.currentStreak}d
              </span>
              <span className="text-slate-600">|</span>
              <span className="flex items-center gap-1 text-indigo-300 font-semibold" title="Total XP">
                <Zap className="w-3.5 h-3.5 text-indigo-400" />
                {userProgress.xp} XP
              </span>
            </div>

            {/* Focus Shield Toggle Button */}
            <button
              id="focus-shield-toggle-btn"
              onClick={onToggleFocusMode}
              className={`hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border shadow-sm ${
                focusModeEnabled
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-400/50 shadow-emerald-500/20'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
              }`}
            >
              {focusModeEnabled ? (
                <>
                  <ShieldCheck className="w-4 h-4 text-emerald-200" />
                  <span>Exam Shield Active</span>
                </>
              ) : (
                <>
                  <ShieldAlert className="w-4 h-4 text-slate-400" />
                  <span>Exam Shield Paused</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex space-x-1 sm:space-x-2 border-t border-slate-800/80 pt-1.5 pb-1 overflow-x-auto text-xs sm:text-sm scrollbar-none">
          <button
            onClick={() => !isQuizActive && setActiveTab('dashboard')}
            disabled={isQuizActive}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'dashboard'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60 disabled:opacity-40 disabled:cursor-not-allowed'
            }`}
          >
            <span>📊</span>
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => !isQuizActive && setActiveTab('study-plan')}
            disabled={isQuizActive}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'study-plan'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60 disabled:opacity-40 disabled:cursor-not-allowed'
            }`}
          >
            <span>✨</span>
            <span>AI Study Plan</span>
          </button>

          <button
            onClick={() => !isQuizActive && setActiveTab('timetable')}
            disabled={isQuizActive}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'timetable'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60 disabled:opacity-40 disabled:cursor-not-allowed'
            }`}
          >
            <span>📅</span>
            <span>Timetable</span>
          </button>

          <button
            onClick={() => !isQuizActive && setActiveTab('tutor')}
            disabled={isQuizActive}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap flex items-center gap-1.5 relative ${
              activeTab === 'tutor'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60 disabled:opacity-40 disabled:cursor-not-allowed'
            }`}
          >
            <span>🤖</span>
            <span>AI Study Tutor</span>
            {isQuizActive && (
              <span className="text-[9px] bg-rose-500/80 text-white px-1.5 py-0.2 rounded font-bold">
                Paused
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('quiz')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'quiz'
                ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <span>🎯</span>
            <span>Quizzes & Earn Pass</span>
            {isQuizActive && (
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            )}
          </button>

          <button
            onClick={() => !isQuizActive && setActiveTab('apps')}
            disabled={isQuizActive}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'apps'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60 disabled:opacity-40 disabled:cursor-not-allowed'
            }`}
          >
            <span>🛡️</span>
            <span>Blocker & Screen Pass</span>
            {screenTimePass.active && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            )}
          </button>

          <button
            onClick={() => !isQuizActive && setActiveTab('leaderboard')}
            disabled={isQuizActive}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'leaderboard'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60 disabled:opacity-40 disabled:cursor-not-allowed'
            }`}
          >
            <span>🏆</span>
            <span>Badges & Leaderboard</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
