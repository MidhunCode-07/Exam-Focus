import React, { useState } from 'react';
import {
  Trophy,
  Award,
  Flame,
  Zap,
  CheckCircle2,
  Lock,
  Unlock,
  Sparkles,
  ShieldCheck,
  Moon,
  TrendingUp,
  UserCheck,
  Medal,
} from 'lucide-react';
import { BadgeItem, LeaderboardEntry, UserProgress } from '../types';
import { gradLightbulbLadderImg, studyFutureGoalsImg } from '../assets/images';

interface LeaderboardAndBadgesProps {
  badges: BadgeItem[];
  leaderboard: LeaderboardEntry[];
  userProgress: UserProgress;
}

export const LeaderboardAndBadges: React.FC<LeaderboardAndBadgesProps> = ({
  badges,
  leaderboard,
  userProgress,
}) => {
  const [activeTab, setActiveTab] = useState<'leaderboard' | 'badges'>('leaderboard');
  const [badgeFilter, setBadgeFilter] = useState<string>('All');

  const filteredBadges =
    badgeFilter === 'All'
      ? badges
      : badges.filter((b) => b.category.toLowerCase() === badgeFilter.toLowerCase());

  const getBadgeIcon = (iconName: string) => {
    switch (iconName) {
      case 'Flame':
        return <Flame className="w-5 h-5 text-amber-400 fill-amber-400" />;
      case 'Award':
        return <Award className="w-5 h-5 text-purple-400" />;
      case 'Unlock':
        return <Unlock className="w-5 h-5 text-emerald-400" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-5 h-5 text-indigo-400" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-amber-300" />;
      case 'Moon':
        return <Moon className="w-5 h-5 text-blue-400" />;
      case 'Trophy':
      default:
        return <Trophy className="w-5 h-5 text-amber-400" />;
    }
  };

  const currentLevelProgress = Math.min(100, Math.round((userProgress.xp % 300) / 3));

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* 1. TOP GAMIFICATION STATS HEADER */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden group">
        {/* Ladder to Graduation Cap Ambiance Background Glow */}
        <img
          src={gradLightbulbLadderImg}
          alt="Ladder to Graduation"
          referrerPolicy="no-referrer"
          className="absolute right-0 top-0 w-80 h-full object-cover object-center opacity-15 group-hover:opacity-25 transition-opacity duration-700 pointer-events-none hidden md:block"
        />
        <div className="absolute right-0 top-0 w-80 h-full bg-gradient-to-l from-transparent via-slate-900/80 to-slate-900 pointer-events-none hidden md:block" />

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6 relative z-10">
          <div className="space-y-1 max-w-lg">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-bold mb-2">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              Focus & Mastery League
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Gamified Progress & Leaderboard
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Earn XP by completing focused study sessions, mastering weak topics, and scoring &ge;80%
              on exams. Climb the academic knowledge ladder to graduation honors!
            </p>
          </div>

          {/* Level & XP Capsule */}
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4 min-w-[260px] space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white flex items-center gap-1.5">
                <span className="w-6 h-6 rounded-md bg-indigo-600 flex items-center justify-center text-[11px] font-bold">
                  {userProgress.level}
                </span>
                Level {userProgress.level} Scholar
              </span>
              <span className="text-indigo-300 font-mono font-bold">{userProgress.xp} XP</span>
            </div>

            <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-amber-500 to-rose-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${currentLevelProgress}%` }}
              />
            </div>
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>{userProgress.xp % 300} XP this tier</span>
              <span>{300 - (userProgress.xp % 300)} XP to Lvl {userProgress.level + 1}</span>
            </div>
          </div>
        </div>

        {/* 4 Stats Chips */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6">
          <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3 text-center">
            <Flame className="w-4 h-4 text-amber-400 mx-auto mb-1 fill-amber-400" />
            <span className="text-base font-bold text-white block">{userProgress.currentStreak} Days</span>
            <span className="text-[10px] text-slate-400 uppercase font-semibold">Active Streak</span>
          </div>

          <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3 text-center">
            <Award className="w-4 h-4 text-purple-400 mx-auto mb-1" />
            <span className="text-base font-bold text-white block">{userProgress.quizzesCompleted}</span>
            <span className="text-[10px] text-slate-400 uppercase font-semibold">Quizzes Passed</span>
          </div>

          <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3 text-center">
            <Unlock className="w-4 h-4 text-emerald-400 mx-auto mb-1" />
            <span className="text-base font-bold text-white block">{userProgress.rewardsUnlocked}</span>
            <span className="text-[10px] text-slate-400 uppercase font-semibold">Passes Redeemed</span>
          </div>

          <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3 text-center">
            <Medal className="w-4 h-4 text-indigo-400 mx-auto mb-1" />
            <span className="text-base font-bold text-white block">
              {badges.filter((b) => b.unlocked).length} / {badges.length}
            </span>
            <span className="text-[10px] text-slate-400 uppercase font-semibold">Badges Unlocked</span>
          </div>
        </div>
      </div>

      {/* 2. TAB TOGGLE: LEADERBOARD VS BADGES */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('leaderboard')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'leaderboard'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/25'
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            <span>Top Users Leaderboard</span>
          </button>

          <button
            onClick={() => setActiveTab('badges')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'badges'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/25'
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>Milestone Badges ({badges.filter((b) => b.unlocked).length})</span>
          </button>
        </div>

        {activeTab === 'badges' && (
          <div className="flex items-center gap-1 overflow-x-auto text-xs">
            {['All', 'Streak', 'Accuracy', 'Focus', 'Mastery'].map((cat) => (
              <button
                key={cat}
                onClick={() => setBadgeFilter(cat)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  badgeFilter === cat
                    ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 3. LEADERBOARD VIEW */}
      {activeTab === 'leaderboard' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight">
                Global Exam Focus Leaderboard
              </h3>
              <p className="text-xs text-slate-400">
                Ranked by Total Focus XP accrued from study time & quiz performance.
              </p>
            </div>
            <div className="text-xs text-indigo-300 font-semibold bg-indigo-500/10 px-3 py-1 rounded-lg border border-indigo-500/20">
              Live Season 1
            </div>
          </div>

          <div className="space-y-2 pt-2">
            {leaderboard.map((user) => {
              const isTop3 = user.rank <= 3;
              const isUser = user.isCurrentUser;

              return (
                <div
                  key={user.id}
                  className={`p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                    isUser
                      ? 'bg-indigo-950/40 border-indigo-500 shadow-md shadow-indigo-500/10'
                      : isTop3
                      ? 'bg-slate-800/60 border-slate-700/80'
                      : 'bg-slate-900/60 border-slate-800/80'
                  }`}
                >
                  <div className="flex items-center gap-3 sm:gap-4">
                    {/* Rank badge */}
                    <div className="w-7 text-center font-mono font-black text-sm">
                      {user.rank === 1 ? (
                        <span className="text-amber-400 text-base">🥇</span>
                      ) : user.rank === 2 ? (
                        <span className="text-slate-300 text-base">🥈</span>
                      ) : user.rank === 3 ? (
                        <span className="text-amber-600 text-base">🥉</span>
                      ) : (
                        <span className="text-slate-500 text-xs">#{user.rank}</span>
                      )}
                    </div>

                    {/* Avatar */}
                    <div
                      className={`w-9 h-9 rounded-xl ${user.avatarBg} text-white font-bold text-xs flex items-center justify-center shadow`}
                    >
                      {user.name.slice(0, 2).toUpperCase()}
                    </div>

                    {/* Name & Academic field */}
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs sm:text-sm font-bold text-white">
                          {user.name}
                        </span>
                        {isUser && (
                          <span className="text-[10px] bg-rose-500/20 text-rose-300 px-1.5 py-0.2 rounded font-bold border border-rose-500/30">
                            YOU
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400">{user.academicField}</p>
                    </div>
                  </div>

                  {/* XP & Stats */}
                  <div className="flex items-center gap-3 sm:gap-6 text-right">
                    <div className="hidden sm:block text-center">
                      <span className="text-xs font-bold text-amber-400 flex items-center gap-1 justify-center">
                        <Flame className="w-3.5 h-3.5 fill-amber-400" />
                        {user.streak}d
                      </span>
                      <span className="text-[10px] text-slate-500">Streak</span>
                    </div>

                    <div className="hidden sm:block text-center">
                      <span className="text-xs font-bold text-slate-300">
                        {user.quizzesPassed}
                      </span>
                      <span className="text-[10px] text-slate-500 block">Tests</span>
                    </div>

                    <div className="min-w-[70px] text-right">
                      <span className="text-sm font-mono font-black text-indigo-400 block">
                        {user.xp.toLocaleString()}
                      </span>
                      <span className="text-[10px] text-slate-500 uppercase font-semibold">
                        Focus XP
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. BADGES GRID VIEW */}
      {activeTab === 'badges' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredBadges.map((badge) => {
            return (
              <div
                key={badge.id}
                className={`p-5 rounded-2xl border transition-all flex flex-col justify-between shadow-md ${
                  badge.unlocked
                    ? 'bg-slate-900 border-indigo-500/40 hover:border-indigo-500'
                    : 'bg-slate-900/60 border-slate-800 opacity-60'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div
                      className={`w-11 h-11 rounded-xl flex items-center justify-center shadow-md ${
                        badge.unlocked
                          ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
                          : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      {getBadgeIcon(badge.icon)}
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-bold text-amber-400 font-mono">
                        +{badge.xpReward} XP
                      </span>
                      <span
                        className={`block text-[10px] uppercase font-bold tracking-wider mt-0.5 ${
                          badge.unlocked ? 'text-emerald-400' : 'text-slate-500'
                        }`}
                      >
                        {badge.unlocked ? 'Unlocked' : 'Locked'}
                      </span>
                    </div>
                  </div>

                  <h4 className="text-sm font-bold text-white mb-1">{badge.title}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">{badge.description}</p>
                </div>

                <div className="pt-4 border-t border-slate-800/80 mt-4 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">{badge.progressText}</span>
                  {badge.unlocked && badge.unlockedAt && (
                    <span className="text-indigo-400 font-medium">{badge.unlockedAt}</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Graduation & Future Milestone Footer Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl mt-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-0 items-center">
          <div className="md:col-span-4 relative h-36 md:h-44 overflow-hidden group">
            <img
              src={studyFutureGoalsImg}
              alt="Build Your Future"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent md:bg-gradient-to-r md:from-transparent md:to-slate-900" />
            <div className="absolute bottom-3 left-3">
              <span className="text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider bg-amber-400 text-slate-950 shadow">
                Academic Honors
              </span>
            </div>
          </div>
          <div className="md:col-span-8 p-5 space-y-2">
            <h4 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              “Every Quiz Question Is a Step to Your Degree”
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Academic achievement isn't just about cramming the night before. By maintaining your daily streak,
              clearing 5-question micro-quizzes, and climbing the leaderboard, you establish habits that carry you
              straight through to graduation with honors.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
