import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Zap,
  Flame,
  Clock,
  BookOpen,
  Award,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Calendar,
  Shield,
  ArrowRight,
  TrendingUp,
  AlertTriangle,
  Lightbulb,
  Check,
} from 'lucide-react';
import {
  AcademicField,
  ExamItem,
  UserProgress,
  RecentlyStudiedItem,
  ScreenTimePass,
  PenaltyState,
  PersonalizedStudyPlan,
  StudentPerformanceProfile,
} from '../types';
import { deepFocusNightImg, studyFutureGoalsImg } from '../assets/images';

interface DashboardViewProps {
  currentField: AcademicField;
  exams: ExamItem[];
  userProgress: UserProgress;
  performanceProfile: StudentPerformanceProfile;
  studyPlan: PersonalizedStudyPlan | null;
  recentlyStudied: RecentlyStudiedItem[];
  screenTimePass: ScreenTimePass;
  penaltyState: PenaltyState;
  onNavigateToQuiz: (subject?: string, topic?: string) => void;
  onNavigateToTutor: (subject?: string, topic?: string) => void;
  onNavigateToStudyPlan: () => void;
  onNavigateToTimetable: () => void;
  isQuizActive: boolean;
  onAddXP: (amount: number) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  currentField,
  exams,
  userProgress,
  performanceProfile,
  studyPlan,
  recentlyStudied,
  screenTimePass,
  penaltyState,
  onNavigateToQuiz,
  onNavigateToTutor,
  onNavigateToStudyPlan,
  onNavigateToTimetable,
  isQuizActive,
  onAddXP,
}) => {
  // Focus Stopwatch state (matching Image 4 Time Tracker widget)
  const [stopwatchSeconds, setStopwatchSeconds] = useState(1);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [checklist, setChecklist] = useState({
    learnNew: true,
    weakSkill: false,
    takeAction: false,
    buildFuture: false,
  });

  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setStopwatchSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  const formatStopwatch = (totalSecs: number) => {
    const hrs = Math.floor(totalSecs / 3600);
    const mins = Math.floor((totalSecs % 3600) / 60);
    const secs = totalSecs % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins
      .toString()
      .padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleToggleTimer = () => {
    if (!isTimerRunning) {
      setIsTimerRunning(true);
    } else {
      setIsTimerRunning(false);
      // Reward XP for focused time if > 60 seconds
      if (stopwatchSeconds > 60) {
        onAddXP(25);
      }
    }
  };

  // Weekly study hours data for Image 4 chart
  const weeklyStudyDots = [
    { day: 'Mo', hours: '1h 30m', val: 55, active: false },
    { day: 'Tue', hours: '2h 15m', val: 75, active: false },
    { day: 'Wed', hours: '1h 45m', val: 60, active: false },
    { day: 'Thu', hours: '3h 00m', val: 95, active: false },
    { day: 'Fri', hours: '2h 30m', val: 80, active: false },
    { day: 'Sat', hours: '1h 15m', val: 50, active: false },
    { day: 'Sun', hours: '0h 45m', val: 35, active: true },
  ];

  // Calendar streak days (matching Image 4 `09 10 11 12 13 14 15 16`)
  const streakDays = [
    { num: '09', done: true },
    { num: '10', done: true },
    { num: '11', done: true },
    { num: '12', done: true },
    { num: '13', done: true },
    { num: '14', done: true },
    { num: '15', done: true, isToday: true },
    { num: '16', done: false },
  ];

  const upcomingExam = exams[0];
  const totalTopicsCount = exams.reduce((acc, e) => acc + e.syllabusTopics.length, 0) || 16;
  const masteredTopicsCount = performanceProfile.masteredTopics.length || 7;

  // Grab today's tasks from the study plan if available, or fallback
  const todayTasks = studyPlan?.days?.[0]?.tasks || [
    {
      id: 'task-1',
      title: 'Active Recall & Topic Drill',
      subject: upcomingExam?.subject || 'Core Exam Discipline',
      topic: upcomingExam?.syllabusTopics?.[0] || 'High-Weightage Concept',
      timeSlot: '07:00 AM - 08:30 AM',
      durationMinutes: 90,
      type: 'concept_review' as const,
      completed: true,
      priority: 'High' as const,
      reasonForInclusion: 'Upcoming board/university exam in 3 days.',
    },
    {
      id: 'task-2',
      title: 'Targeted Remediation Drill',
      subject: upcomingExam?.subject || 'Core Exam Discipline',
      topic: performanceProfile.weakTopics[0] || 'Identified Weak Areas',
      timeSlot: '10:00 AM - 11:30 AM',
      durationMinutes: 90,
      type: 'formula_drill' as const,
      completed: false,
      priority: 'High' as const,
      reasonForInclusion: 'Automated remediation triggered by quiz score < 70%.',
    },
    {
      id: 'task-3',
      title: 'Exam Readiness Quiz & Reward Run',
      subject: upcomingExam?.subject || 'Core Exam Discipline',
      topic: 'Practice Mock Set',
      timeSlot: '02:30 PM - 03:15 PM',
      durationMinutes: 45,
      type: 'practice_quiz' as const,
      completed: false,
      priority: 'Medium' as const,
      reasonForInclusion: 'Score 80%+ to unlock 30m social media break.',
    },
  ];

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* 1. TOP GREETING HEADER (Matching Image 4) */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden">
        <div className="space-y-1 relative z-10">
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Dashboard
            </h1>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              {currentField}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-300">
            Welcome back, <strong className="text-white">Alex</strong>! Ready to level up your exam
            mastery today?
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 relative z-10">
          <button
            id="join-focus-session-btn"
            onClick={handleToggleTimer}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-md ${
              isTimerRunning
                ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-600/30 animate-pulse'
                : 'bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white shadow-rose-600/30'
            }`}
          >
            {isTimerRunning ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>Focus Session Running</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>Start Focus Session</span>
              </>
            )}
          </button>

          <button
            onClick={() => onNavigateToTutor()}
            disabled={isQuizActive}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition-all flex items-center gap-1.5 disabled:opacity-40"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Ask AI Tutor</span>
          </button>
        </div>
      </div>

      {/* 2. FOUR KEY METRIC CARDS (Exact 4 Cards from Image 4) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Subjects Enrolled */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Subjects Enrolled</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-white">
              {exams.length}{' '}
              <span className="text-xs font-normal text-slate-400">Exams</span>
            </div>
            <p className="text-[11px] text-indigo-300 mt-1 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
              Next: {upcomingExam?.subject || 'All subjects synced'}
            </p>
          </div>
        </div>

        {/* Card 2: Topics Mastered */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Topics Mastered</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-white">
              {masteredTopicsCount}{' '}
              <span className="text-xs font-normal text-slate-400">/ {totalTopicsCount}</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all"
                style={{ width: `${Math.round((masteredTopicsCount / totalTopicsCount) * 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* Card 3: Quizzes Taken */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Quizzes Taken</span>
            <div className="w-8 h-8 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-white">
              {userProgress.quizzesCompleted}{' '}
              <span className="text-xs font-normal text-slate-400">Tests</span>
            </div>
            <p className="text-[11px] text-purple-300 mt-1 flex items-center gap-1">
              <Award className="w-3 h-3 text-purple-400" />
              Avg Score: {performanceProfile.averageScore || 82}% (Pass rate 90%)
            </p>
          </div>
        </div>

        {/* Card 4: Streak Tracker Widget (Matching Image 4 visual) */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between shadow-md">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" /> Streak Tracker
            </span>
            <span className="text-[11px] font-bold text-amber-300">
              {userProgress.currentStreak} Days
            </span>
          </div>

          {/* Sequential Day Circles (from Image 4: 09 10 11 12 13 14 15 16) */}
          <div className="flex items-center justify-between gap-1 my-2">
            {streakDays.map((d, idx) => (
              <div
                key={idx}
                className={`w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold transition-all ${
                  d.isToday
                    ? 'bg-amber-500 text-slate-950 ring-2 ring-amber-400 shadow-md shadow-amber-500/30'
                    : d.done
                    ? 'bg-slate-800 text-amber-300 border border-amber-500/40'
                    : 'bg-slate-800/40 text-slate-600 border border-slate-700/40'
                }`}
              >
                {d.num}
              </div>
            ))}
          </div>

          <p className="text-[10px] text-slate-400 text-center font-medium">
            Keep going! +50 XP bonus for maintaining streak.
          </p>
        </div>
      </div>

      {/* 3. MIDDLE ROW: TIME SPENT LEARNING (CHART) + TODAY'S SCHEDULE TIMELINE (From Image 4) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Time Spent Learning Weekly Chart (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-white tracking-tight">Time Spent Learning</h3>
                <p className="text-xs text-slate-400">Total: 12h 45m this week</p>
              </div>
              <div className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
                This Week
              </div>
            </div>

            {/* Visual Dot/Bar Chart */}
            <div className="h-44 flex items-end justify-between gap-2 px-2 pt-4 pb-2">
              {weeklyStudyDots.map((col, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center gap-2 group">
                  <div className="relative w-full flex flex-col items-center justify-end h-32">
                    {/* Tooltip on hover */}
                    <div className="absolute -top-7 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-800 text-[10px] text-white px-2 py-0.5 rounded shadow pointer-events-none whitespace-nowrap z-20 border border-slate-700">
                      {col.hours}
                    </div>

                    {/* Bar Pill */}
                    <div
                      className={`w-4 rounded-full transition-all duration-500 ${
                        col.active
                          ? 'bg-gradient-to-t from-indigo-600 to-rose-500 shadow-md shadow-rose-500/20'
                          : 'bg-slate-800 group-hover:bg-indigo-500/50'
                      }`}
                      style={{ height: `${col.val}%` }}
                    />
                  </div>
                  <span
                    className={`text-[11px] font-semibold ${
                      col.active ? 'text-indigo-400 font-bold' : 'text-slate-400'
                    }`}
                  >
                    {col.day}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              +18% focus compared to last week
            </span>
            <button
              onClick={onNavigateToStudyPlan}
              className="text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1"
            >
              Plan Ahead &rarr;
            </button>
          </div>
        </div>

        {/* Right Column: Today's Schedule Timeline (7 cols) (Matching Image 4) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white tracking-tight">Today's Schedule</h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold">
                  Personalized AI Plan
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Calibrated to upcoming exam dates & weak quiz areas
              </p>
            </div>

            <button
              onClick={onNavigateToStudyPlan}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300"
            >
              View Full Plan &rarr;
            </button>
          </div>

          {/* Timeline tasks */}
          <div className="space-y-3">
            {todayTasks.slice(0, 3).map((task, idx) => {
              const isRemediation = task.type === 'formula_drill' || task.title.includes('Remediation');
              const isQuiz = task.type === 'practice_quiz';

              return (
                <div
                  key={task.id || idx}
                  className={`p-3.5 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isRemediation
                      ? 'bg-amber-500/5 border-amber-500/30'
                      : isQuiz
                      ? 'bg-indigo-500/5 border-indigo-500/30'
                      : 'bg-slate-800/50 border-slate-700/60'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                        isRemediation
                          ? 'bg-amber-500/20 text-amber-300'
                          : isQuiz
                          ? 'bg-indigo-500/20 text-indigo-300'
                          : 'bg-emerald-500/20 text-emerald-300'
                      }`}
                    >
                      {isRemediation ? (
                        <AlertTriangle className="w-4 h-4" />
                      ) : isQuiz ? (
                        <Zap className="w-4 h-4" />
                      ) : (
                        <BookOpen className="w-4 h-4" />
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{task.title}</span>
                        {isRemediation && (
                          <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-semibold">
                            Weak Area Target
                          </span>
                        )}
                      </div>

                      <p className="text-[11px] text-slate-400">
                        {task.subject} &bull; <span className="text-indigo-300">{task.topic}</span>
                      </p>

                      <p className="text-[10px] text-slate-500 mt-0.5 flex items-center gap-2">
                        <span className="flex items-center gap-1 text-slate-400 font-mono">
                          <Clock className="w-3 h-3 text-slate-500" />
                          {task.timeSlot}
                        </span>
                        <span>&bull; {task.durationMinutes} mins</span>
                      </p>
                    </div>
                  </div>

                  {/* Action button */}
                  <div className="shrink-0 flex items-center gap-2">
                    {isQuiz ? (
                      <button
                        onClick={() => onNavigateToQuiz(task.subject, task.topic)}
                        className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1"
                      >
                        <Zap className="w-3 h-3" />
                        <span>Take Quiz</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => onNavigateToTutor(task.subject, task.topic)}
                        disabled={isQuizActive}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all flex items-center gap-1 disabled:opacity-40"
                      >
                        <span>Start Learning</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 4. BOTTOM ROW: RECENTLY STUDIED TABLE + TIME TRACKER WIDGET (From Image 4) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Recently Studied Courses Table (8 cols) */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white tracking-tight">Recently Studied</h3>
            <button
              onClick={onNavigateToTimetable}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300"
            >
              All Courses &rarr;
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="pb-3 font-semibold">Course / Subject Name</th>
                  <th className="pb-3 font-semibold">Start Time</th>
                  <th className="pb-3 font-semibold">End Time</th>
                  <th className="pb-3 font-semibold">Total Time</th>
                  <th className="pb-3 font-semibold text-right">Action / XP</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {recentlyStudied.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 font-medium text-white">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-indigo-500" />
                        <div>
                          <span className="block">{item.courseName}</span>
                          <span className="text-[10px] text-slate-400">{item.topic}</span>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 text-slate-300">{item.startTime}</td>
                    <td className="py-3 text-slate-300">{item.endTime}</td>
                    <td className="py-3 text-slate-300 font-semibold">{item.totalTimeSpent}</td>
                    <td className="py-3 text-right">
                      <button
                        onClick={() => onNavigateToQuiz(item.courseName, item.topic)}
                        className="text-xs font-bold text-indigo-400 hover:text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 px-2.5 py-1 rounded-lg border border-indigo-500/20 transition-colors"
                      >
                        Quiz &bull; +{item.xpEarned} XP
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column: Time Tracker Stopwatch Card (4 cols) with Deep Focus Monitor Light Ambiance */}
        <div className="lg:col-span-4 rounded-2xl p-5 shadow-xl flex flex-col justify-between relative overflow-hidden border border-slate-800 group">
          {/* Deep Focus Desk Night Ambiance Image Background */}
          <img
            src={deepFocusNightImg}
            alt="Deep Focus Study Desk"
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover object-center opacity-25 group-hover:scale-105 group-hover:opacity-35 transition-all duration-700 pointer-events-none"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950/85 via-slate-950/75 to-rose-950/90 pointer-events-none" />

          <div className="relative z-10 flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
              Deep Focus Tracker
            </h3>
            <span className="text-[10px] font-mono font-bold bg-slate-900/90 text-rose-300 px-2 py-0.5 rounded border border-rose-500/30">
              Session Goal: 02:00:00
            </span>
          </div>

          {/* Central glowing circular button & Digital clock (from Image 4) */}
          <div className="relative z-10 flex flex-col items-center justify-center my-4 space-y-4">
            <button
              onClick={handleToggleTimer}
              className="relative group focus:outline-none"
              title={isTimerRunning ? 'Pause Focus Session' : 'Start Focus Session'}
            >
              <div
                className={`w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 shadow-2xl ${
                  isTimerRunning
                    ? 'bg-gradient-to-tr from-amber-500 to-rose-600 shadow-rose-600/40 scale-105 ring-4 ring-rose-500/30'
                    : 'bg-gradient-to-tr from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 shadow-rose-600/30 group-hover:scale-105'
                }`}
              >
                {isTimerRunning ? (
                  <Pause className="w-8 h-8 text-white fill-white" />
                ) : (
                  <Play className="w-8 h-8 text-white fill-white translate-x-0.5" />
                )}
              </div>
            </button>

            <div className="text-center">
              <div className="text-3xl sm:text-4xl font-mono font-black text-white tracking-wider drop-shadow-md">
                {formatStopwatch(stopwatchSeconds)}
              </div>
              <p className="text-[11px] text-slate-300 mt-1 font-medium">
                {isTimerRunning
                  ? '🔥 Deep focus engaged — Distraction shield active'
                  : 'Click play to start tracked study session'}
              </p>
            </div>
          </div>

          {/* Shield Status pill */}
          <div className="relative z-10 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 text-emerald-400 font-semibold text-[11px]">
              <Shield className="w-3.5 h-3.5" />
              Shield: 8 Apps Locked
            </span>
            <button
              onClick={() => setStopwatchSeconds(0)}
              className="text-slate-400 hover:text-slate-200 p-1 transition-colors"
              title="Reset Timer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* 5. INSPIRATIONAL ACTION MINDSET BANNER (Featuring "YOUR FREE TIME CAN BUILD YOUR FUTURE") */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
          {/* Visual Showcase (5 cols) */}
          <div className="lg:col-span-5 relative min-h-[220px] lg:min-h-[260px] overflow-hidden group">
            <img
              src={studyFutureGoalsImg}
              alt="Your Free Time Can Build Your Future"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent lg:bg-gradient-to-r lg:from-transparent lg:to-slate-900" />
            <div className="absolute bottom-4 left-4 right-4 z-10">
              <span className="inline-block px-2.5 py-1 rounded-md bg-emerald-500/90 text-slate-950 text-[10px] font-black uppercase tracking-wider mb-1">
                Mindset &bull; Skills &bull; Discipline
              </span>
              <h4 className="text-sm font-bold text-white drop-shadow">
                "Your Free Time Can Build Your Future"
              </h4>
              <p className="text-[11px] text-slate-300 drop-shadow">
                Invest Time &bull; Pass Quizzes &bull; Earn Real Rewards
              </p>
            </div>
          </div>

          {/* Core Philosophy & Interactive Action Checklist (7 cols) */}
          <div className="lg:col-span-7 p-6 flex flex-col justify-between space-y-4">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-bold">
                <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                Positive Reinforcement: First Study, Then Earn Screen Time
              </div>
              <h3 className="text-lg sm:text-xl font-black text-white tracking-tight">
                Transform Scrolling Impulses into Exam Excellence
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Every 25 minutes of deep focus followed by an 80%+ quiz score guarantees real, guilt-free
                entertainment passes. Complete today's 4 action pillars to build academic discipline:
              </p>
            </div>

            {/* Daily 4 Action Pillars */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-2.5 text-xs">
              <div className="font-bold text-white flex items-center justify-between pb-1 border-b border-slate-800">
                <span className="flex items-center gap-1.5 text-indigo-300">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" />
                  Today's Execution Checklist:
                </span>
                <span className="text-[10px] text-emerald-400 font-mono font-bold">
                  {Object.values(checklist).filter(Boolean).length} of 4 Complete
                </span>
              </div>

              <button
                onClick={() => setChecklist((prev) => ({ ...prev, learnNew: !prev.learnNew }))}
                className="w-full flex items-center gap-2.5 text-left cursor-pointer group py-0.5"
              >
                <div
                  className={`w-4 h-4 rounded flex items-center justify-center border transition-colors ${
                    checklist.learnNew
                      ? 'bg-emerald-500 border-emerald-400 text-white'
                      : 'border-slate-600 bg-slate-800 group-hover:border-slate-500'
                  }`}
                >
                  {checklist.learnNew && <Check className="w-3 h-3" />}
                </div>
                <span className={checklist.learnNew ? 'line-through text-slate-400' : 'text-slate-200'}>
                  1. Learn Something New (Clarify 1 key concept with AI Tutor)
                </span>
              </button>

              <button
                onClick={() => setChecklist((prev) => ({ ...prev, weakSkill: !prev.weakSkill }))}
                className="w-full flex items-center gap-2.5 text-left cursor-pointer group py-0.5"
              >
                <div
                  className={`w-4 h-4 rounded flex items-center justify-center border transition-colors ${
                    checklist.weakSkill
                      ? 'bg-emerald-500 border-emerald-400 text-white'
                      : 'border-slate-600 bg-slate-800 group-hover:border-slate-500'
                  }`}
                >
                  {checklist.weakSkill && <Check className="w-3 h-3" />}
                </div>
                <span className={checklist.weakSkill ? 'line-through text-slate-400' : 'text-slate-200'}>
                  2. Drill a Weak Topic (Targeted remediation block)
                </span>
              </button>

              <button
                onClick={() => setChecklist((prev) => ({ ...prev, takeAction: !prev.takeAction }))}
                className="w-full flex items-center gap-2.5 text-left cursor-pointer group py-0.5"
              >
                <div
                  className={`w-4 h-4 rounded flex items-center justify-center border transition-colors ${
                    checklist.takeAction
                      ? 'bg-emerald-500 border-emerald-400 text-white'
                      : 'border-slate-600 bg-slate-800 group-hover:border-slate-500'
                  }`}
                >
                  {checklist.takeAction && <Check className="w-3 h-3" />}
                </div>
                <span className={checklist.takeAction ? 'line-through text-slate-400' : 'text-slate-200'}>
                  3. Take Action (Score &ge; 80% on practice quiz)
                </span>
              </button>

              <button
                onClick={() => setChecklist((prev) => ({ ...prev, buildFuture: !prev.buildFuture }))}
                className="w-full flex items-center gap-2.5 text-left cursor-pointer group py-0.5"
              >
                <div
                  className={`w-4 h-4 rounded flex items-center justify-center border transition-colors ${
                    checklist.buildFuture
                      ? 'bg-emerald-500 border-emerald-400 text-white'
                      : 'border-slate-600 bg-slate-800 group-hover:border-slate-500'
                  }`}
                >
                  {checklist.buildFuture && <Check className="w-3 h-3" />}
                </div>
                <span className={checklist.buildFuture ? 'line-through text-slate-400' : 'text-slate-200'}>
                  4. Unlock 30-Minute Screen Pass Guilt-Free
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
