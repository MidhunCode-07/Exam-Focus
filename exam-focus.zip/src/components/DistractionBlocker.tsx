import React from 'react';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  Lock,
  Unlock,
  Clock,
  Instagram,
  Youtube,
  MessageSquare,
  Music2,
  Compass,
  Tv,
  Gamepad2,
  Twitter,
  AlertTriangle,
  Play,
  Check,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { DistractingApp, ScreenTimePass, PenaltyState } from '../types';
import { studyFutureGoalsImg } from '../assets/images';

interface DistractionBlockerProps {
  apps: DistractingApp[];
  setApps: React.Dispatch<React.SetStateAction<DistractingApp[]>>;
  focusModeEnabled: boolean;
  onToggleFocusMode: () => void;
  screenTimePass: ScreenTimePass;
  penaltyState: PenaltyState;
  onOpenAppSimulation: (app: DistractingApp) => void;
  onNavigateToQuiz: () => void;
}

export const DistractionBlocker: React.FC<DistractionBlockerProps> = ({
  apps,
  setApps,
  focusModeEnabled,
  onToggleFocusMode,
  screenTimePass,
  penaltyState,
  onOpenAppSimulation,
  onNavigateToQuiz,
}) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case 'Instagram':
        return Instagram;
      case 'Youtube':
        return Youtube;
      case 'MessageSquare':
        return MessageSquare;
      case 'Music2':
        return Music2;
      case 'Compass':
        return Compass;
      case 'Tv':
        return Tv;
      case 'Gamepad2':
        return Gamepad2;
      case 'Twitter':
        return Twitter;
      default:
        return Lock;
    }
  };

  const toggleLinkApp = (appId: string) => {
    setApps((prev) =>
      prev.map((app) =>
        app.id === appId ? { ...app, accountLinked: !app.accountLinked } : app
      )
    );
  };

  const toggleBlockApp = (appId: string) => {
    setApps((prev) =>
      prev.map((app) =>
        app.id === appId ? { ...app, blocked: !app.blocked } : app
      )
    );
  };

  const isAppCurrentlyLocked = (app: DistractingApp) => {
    // If penalty is active, it's strictly locked!
    if (penaltyState.active) return true;
    // If focus mode is enabled and app is blocked
    if (focusModeEnabled && app.blocked) {
      // If student has an active screen time pass earned through quiz score ≥ 80%
      if (screenTimePass.active && screenTimePass.remainingSeconds > 0) {
        return false; // Unlocked by reward pass!
      }
      return true; // Locked
    }
    return false;
  };

  const totalLinked = apps.filter((a) => a.accountLinked).length;
  const totalBlocked = apps.filter((a) => a.blocked).length;

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 relative overflow-hidden shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-semibold mb-3">
              <Shield className="w-3.5 h-3.5" />
              “First Study, Then Earn Your Screen Time” Positive Reinforcement
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Exam Distraction Blocker & Account Lockdown
            </h2>
            <p className="text-sm text-slate-300 mt-1.5 leading-relaxed">
              Link distracting entertainment and social media accounts. During your exam preparation period,
              these apps remain strictly locked down. Score <strong>80% or higher</strong> on your topic quizzes
              to earn <strong>15 to 30 minutes of controlled screen time</strong>.
            </p>
          </div>

          {/* Quick status widget */}
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4 min-w-[260px] flex flex-col justify-between">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-slate-400 font-semibold">Master Exam Shield</span>
              <button
                onClick={onToggleFocusMode}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                  focusModeEnabled ? 'bg-emerald-600' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    focusModeEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Linked Accounts:</span>
                <span className="font-bold text-white">{totalLinked} of {apps.length}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Enforced App Locks:</span>
                <span className="font-bold text-emerald-400">{totalBlocked} Active</span>
              </div>
              <div className="flex justify-between text-slate-300 pt-1 border-t border-slate-700">
                <span>Screen Time Pass:</span>
                {screenTimePass.active && !penaltyState.active ? (
                  <span className="font-bold text-emerald-400">
                    Active ({formatTime(screenTimePass.remainingSeconds)})
                  </span>
                ) : (
                  <span className="text-slate-400">Locked (Study to earn)</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Global Alert if 30-min penalty is active */}
        {penaltyState.active && (
          <div className="mt-4 p-4 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5 animate-bounce" />
            <div>
              <h4 className="text-sm font-bold text-rose-200">
                30-Minute Penalty Lockdown in Effect: {formatTime(penaltyState.remainingSeconds)}
              </h4>
              <p className="text-xs text-rose-300/90 mt-0.5">
                {penaltyState.reason || 'You exited an active exam quiz early.'} All distracting apps and social media
                remain locked until this penalty expires to maintain academic focus integrity.
              </p>
            </div>
          </div>
        )}

        {/* Active Screen Time Pass Celebration Banner */}
        {screenTimePass.active && !penaltyState.active && (
          <div className="mt-4 p-4 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/30 flex items-center justify-center text-emerald-200">
                <Unlock className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-emerald-200 flex items-center gap-1.5">
                  Screen Time Pass Unlocked!
                  <span className="text-[10px] bg-emerald-500/40 text-emerald-100 px-2 py-0.5 rounded-full font-bold">
                    Score &ge; 80% Reward
                  </span>
                </h4>
                <p className="text-xs text-emerald-300/90 mt-0.5">
                  You have <strong>{formatTime(screenTimePass.remainingSeconds)}</strong> remaining to browse YouTube,
                  Instagram, or games.
                </p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-2xl font-mono font-bold text-emerald-300">
                {formatTime(screenTimePass.remainingSeconds)}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Motivational Mindset Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
          <div className="md:col-span-4 relative min-h-[160px] group overflow-hidden">
            <img
              src={studyFutureGoalsImg}
              alt="Build Your Future"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent md:bg-gradient-to-r md:from-transparent md:to-slate-900" />
            <div className="absolute bottom-3 left-3 text-white">
              <span className="text-[10px] bg-emerald-500/90 text-slate-950 font-black px-2 py-0.5 rounded uppercase tracking-wider">
                Positive Reinforcement
              </span>
            </div>
          </div>
          <div className="md:col-span-8 p-5 flex flex-col justify-center space-y-2">
            <h4 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              “Your Free Time Can Build Your Future”
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              When distracting social media is locked during your exam preparation window, you reclaim 2 to 4 hours of deep cognitive
              focus daily. Scoring <strong>80% or higher</strong> on any topic readiness quiz unlocks 15 to 30 minutes of guilt-free screen time!
            </p>
            <div className="pt-1 flex items-center gap-3 text-xs">
              <button
                onClick={onNavigateToQuiz}
                className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1.5 transition-colors"
              >
                <span>Take a 5-Question Quiz to Unlock Entertainment</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* App Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-indigo-400" />
              Linked Apps & Exam Lock Status
            </h3>
            <p className="text-xs text-slate-400">
              Click any app to simulate launching it or verify its lock screen status
            </p>
          </div>

          <button
            onClick={onNavigateToQuiz}
            className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Earn Screen Time Now
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {apps.map((app) => {
            const Icon = getIconComponent(app.icon);
            const isLocked = isAppCurrentlyLocked(app);

            return (
              <div
                key={app.id}
                className={`bg-slate-900 border rounded-2xl p-4 transition-all duration-200 flex flex-col justify-between group relative overflow-hidden ${
                  isLocked
                    ? 'border-slate-800 hover:border-slate-700'
                    : 'border-emerald-500/40 shadow-lg shadow-emerald-500/5 bg-slate-900/90'
                }`}
              >
                <div>
                  {/* Top Bar: Icon, Category, Status Badge */}
                  <div className="flex items-start justify-between mb-3">
                    <div
                      className={`w-11 h-11 rounded-xl bg-gradient-to-tr ${app.color} flex items-center justify-center text-white shadow-md`}
                    >
                      <Icon className="w-6 h-6" />
                    </div>

                    <div className="flex flex-col items-end">
                      {isLocked ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                          <Lock className="w-3 h-3" />
                          Locked
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 animate-pulse">
                          <Unlock className="w-3 h-3" />
                          Unlocked Pass
                        </span>
                      )}
                      <span className="text-[10px] text-slate-400 mt-1">
                        ~{app.dailyUsageMinutes}m avg/day
                      </span>
                    </div>
                  </div>

                  {/* App Name & Category */}
                  <h4 className="text-sm font-bold text-white tracking-tight">{app.name}</h4>
                  <p className="text-xs text-slate-400 mb-3">{app.category}</p>

                  {/* Toggles: Account Linked & Exam Blocker */}
                  <div className="space-y-2 py-2 border-t border-b border-slate-800/80 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-300 flex items-center gap-1">
                        {app.accountLinked ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <AlertTriangle className="w-3.5 h-3.5 text-slate-500" />
                        )}
                        Account Linked
                      </span>
                      <button
                        onClick={() => toggleLinkApp(app.id)}
                        className={`text-[11px] font-semibold px-2 py-0.5 rounded transition-colors ${
                          app.accountLinked
                            ? 'text-indigo-400 hover:text-indigo-300 bg-indigo-500/10'
                            : 'text-slate-400 hover:text-white bg-slate-800'
                        }`}
                      >
                        {app.accountLinked ? 'Linked' : 'Link'}
                      </button>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-300 flex items-center gap-1">
                        <Shield className="w-3.5 h-3.5 text-indigo-400" />
                        Exam Block
                      </span>
                      <button
                        onClick={() => toggleBlockApp(app.id)}
                        className={`text-[11px] font-semibold px-2 py-0.5 rounded transition-colors ${
                          app.blocked
                            ? 'text-emerald-400 bg-emerald-500/10'
                            : 'text-slate-400 bg-slate-800'
                        }`}
                      >
                        {app.blocked ? 'Enforced' : 'Ignored'}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Launch Simulation Button */}
                <div className="mt-4 pt-1">
                  <button
                    onClick={() => onOpenAppSimulation(app)}
                    className={`w-full py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-sm ${
                      isLocked
                        ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                        : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-600/20'
                    }`}
                  >
                    <Play className="w-3 h-3" />
                    {isLocked ? 'Test Blocker Shield' : 'Open With Screen Pass'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
