import React from 'react';
import { AlertTriangle, Lock } from 'lucide-react';
import { PenaltyState } from '../types';

interface PenaltyBannerProps {
  penaltyState: PenaltyState;
}

export const PenaltyBanner: React.FC<PenaltyBannerProps> = ({ penaltyState }) => {
  if (!penaltyState.active) return null;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-rose-950/80 border-b border-rose-500/40 text-rose-200 px-4 py-3 shadow-lg">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs sm:text-sm">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-300 shrink-0">
            <Lock className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <span className="font-bold text-rose-100 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
              Active 30-Minute Penalty Lockout Enforced
            </span>
            <span className="text-xs text-rose-300/80 block sm:inline sm:ml-2">
              {penaltyState.reason || 'Quiz abandoned early. All entertainment apps are locked until countdown expires.'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="bg-slate-950/90 border border-rose-500/50 px-3 py-1 rounded-lg font-mono font-bold text-rose-400 text-sm tracking-wider">
            {formatTime(penaltyState.remainingSeconds)}
          </div>
        </div>
      </div>
    </div>
  );
};
