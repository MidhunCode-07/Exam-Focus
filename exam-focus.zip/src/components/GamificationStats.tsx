import React from 'react';
import { Flame, Zap, Award, ShieldCheck, Clock, BookCheck } from 'lucide-react';
import { UserProgress } from '../types';

interface GamificationStatsProps {
  progress: UserProgress;
}

export const GamificationStats: React.FC<GamificationStatsProps> = ({ progress }) => {
  const xpForNextLevel = progress.level * 300;
  const currentLevelProgress = Math.min(100, Math.round((progress.xp % 300) / 3));

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-xs">
            Lvl {progress.level}
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">Focus Mastery Level {progress.level}</h4>
            <p className="text-[11px] text-slate-400">{progress.xp} Total Focus XP</p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-xs font-semibold text-indigo-300">
            {progress.xp % 300} / 300 XP to Lvl {progress.level + 1}
          </span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
        <div
          className="bg-gradient-to-r from-indigo-500 to-violet-500 h-full transition-all duration-500 rounded-full"
          style={{ width: `${currentLevelProgress}%` }}
        />
      </div>

      {/* Grid of 4 Key Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
        <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3 text-center">
          <Flame className="w-5 h-5 text-amber-400 mx-auto mb-1 fill-amber-400/20" />
          <span className="text-lg font-bold text-white block">{progress.currentStreak} Days</span>
          <span className="text-[10px] text-slate-400 uppercase font-semibold">Active Streak</span>
        </div>

        <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3 text-center">
          <BookCheck className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
          <span className="text-lg font-bold text-white block">{progress.quizzesCompleted}</span>
          <span className="text-[10px] text-slate-400 uppercase font-semibold">Quizzes Passed</span>
        </div>

        <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3 text-center">
          <Clock className="w-5 h-5 text-indigo-400 mx-auto mb-1" />
          <span className="text-lg font-bold text-white block">{progress.totalStudyMinutes}m</span>
          <span className="text-[10px] text-slate-400 uppercase font-semibold">Earned Screen Time</span>
        </div>

        <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3 text-center">
          <Award className="w-5 h-5 text-purple-400 mx-auto mb-1" />
          <span className="text-lg font-bold text-white block">{progress.rewardsUnlocked}</span>
          <span className="text-[10px] text-slate-400 uppercase font-semibold">Passes Redeemed</span>
        </div>
      </div>
    </div>
  );
};
