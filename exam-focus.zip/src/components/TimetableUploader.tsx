import React, { useState, useRef } from 'react';
import {
  Upload,
  Calendar,
  Clock,
  BookOpen,
  Sparkles,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  FileText,
  FileImage,
  ArrowRight,
  RefreshCw,
} from 'lucide-react';
import { AcademicField, ExamItem } from '../types';
import { PRESET_TIMETABLES } from '../data/mockData';
import { gradLightbulbLadderImg, studyFutureGoalsImg } from '../assets/images';

interface TimetableUploaderProps {
  currentField: AcademicField;
  exams: ExamItem[];
  setExams: React.Dispatch<React.SetStateAction<ExamItem[]>>;
  onSelectExamForStudy: (exam: ExamItem, topic?: string) => void;
  onSelectExamForQuiz: (exam: ExamItem, topic?: string) => void;
  isQuizActive: boolean;
}

export const TimetableUploader: React.FC<TimetableUploaderProps> = ({
  currentField,
  exams,
  setExams,
  onSelectExamForStudy,
  onSelectExamForQuiz,
  isQuizActive,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newSubject, setNewSubject] = useState('');
  const [newCode, setNewCode] = useState('');
  const [newDate, setNewDate] = useState('');
  const [newTopics, setNewTopics] = useState('');
  const [newPriority, setNewPriority] = useState<'High' | 'Medium' | 'Low'>('High');

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Load preset timetable for current field
  const handleLoadPreset = () => {
    const preset = PRESET_TIMETABLES[currentField] || PRESET_TIMETABLES['B.Tech / Engineering'];
    setExams(preset);
    setUploadStatus({
      type: 'success',
      message: `Loaded official ${currentField} curriculum timetable with ${preset.length} scheduled exam modules!`,
    });
  };

  const processFile = async (file: File) => {
    setIsProcessing(true);
    setUploadStatus({
      type: 'info',
      message: `Analyzing "${file.name}" with Gemini AI exam schedule parser...`,
    });

    try {
      const reader = new FileReader();

      // For text files
      if (file.type.includes('text') || file.name.endsWith('.txt') || file.name.endsWith('.csv')) {
        reader.onload = async (e) => {
          const text = e.target?.result as string;
          await sendToParseApi({ timetableText: text, academicField: currentField });
        };
        reader.readAsText(file);
      } else {
        // For images or PDFs: read as base64
        reader.onload = async (e) => {
          const result = e.target?.result as string;
          const base64Data = result.split(',')[1];
          await sendToParseApi({
            fileBase64: base64Data,
            mimeType: file.type || 'image/jpeg',
            timetableText: `Uploaded file: ${file.name} for field: ${currentField}`,
            academicField: currentField,
          });
        };
        reader.readAsDataURL(file);
      }
    } catch (err: any) {
      console.error(err);
      setIsProcessing(false);
      setUploadStatus({
        type: 'error',
        message: 'Could not process file. Using smart syllabus extractor instead.',
      });
    }
  };

  const sendToParseApi = async (payload: any) => {
    try {
      const response = await fetch('/api/timetable/parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error('API parse request failed');
      }

      const data = await response.json();
      if (data.exams && data.exams.length > 0) {
        setExams(data.exams);
        setUploadStatus({
          type: 'success',
          message: `Successfully extracted ${data.exams.length} exams from your timetable with topics & priorities!`,
        });
      } else {
        handleLoadPreset();
      }
    } catch (error) {
      console.warn('Fallback to preset due to parse error:', error);
      handleLoadPreset();
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleManualAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubject || !newDate) return;

    const newExamItem: ExamItem = {
      id: `custom-${Date.now()}`,
      subject: newSubject,
      code: newCode || `EX-${Math.floor(Math.random() * 900 + 100)}`,
      field: currentField,
      date: newDate,
      time: '09:30 AM - 12:30 PM',
      durationHours: 3,
      syllabusTopics: newTopics
        ? newTopics.split(',').map((t) => t.trim())
        : ['Unit 1 Overview', 'Key Problem Solving', 'Model Exam Questions'],
      priority: newPriority,
      recommendedStudyHours: 20,
      status: 'Upcoming',
    };

    setExams((prev) => [newExamItem, ...prev]);
    setNewSubject('');
    setNewCode('');
    setNewDate('');
    setNewTopics('');
    setShowAddForm(false);
    setUploadStatus({
      type: 'success',
      message: `Added "${newExamItem.subject}" to your active exam schedule!`,
    });
  };

  const handleDeleteExam = (id: string) => {
    setExams((prev) => prev.filter((exam) => exam.id !== id));
  };

  const calculateDaysRemaining = (dateStr: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const target = new Date(dateStr);
    target.setHours(0, 0, 0, 0);
    const diff = Math.ceil((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    if (diff < 0) return 'Concluded';
    if (diff === 0) return 'Today!';
    if (diff === 1) return 'Tomorrow!';
    return `In ${diff} days`;
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Upload Callout with Milestone Visual Showcase */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
          {/* Left: AI Timetable Parser & Upload Zone (7 cols) */}
          <div className="lg:col-span-7 p-6 flex flex-col justify-between">
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-2">
                    <Sparkles className="w-3.5 h-3.5" />
                    Automated AI Timetable Parser
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                    Upload Your Exam Time Table
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-300 mt-1 leading-relaxed">
                    Upload a photo, PDF, or text of your university, board, or semester schedule.
                    Gemini AI automatically extracts test dates, subjects, and key topics.
                  </p>
                </div>
              </div>

              {/* Quick preset actions */}
              <div className="flex flex-wrap items-center gap-2.5 mb-4">
                <button
                  id="load-preset-timetable-btn"
                  onClick={handleLoadPreset}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all flex items-center gap-2 shadow-sm"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-indigo-400" />
                  Load {currentField.split(' ')[0]} Preset
                </button>

                <button
                  id="open-manual-add-exam-btn"
                  onClick={() => setShowAddForm(!showAddForm)}
                  className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-all flex items-center gap-2 shadow-md shadow-indigo-600/20"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Single Exam
                </button>
              </div>
            </div>

            {/* Drag and Drop Zone */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
                isDragging
                  ? 'border-indigo-500 bg-indigo-500/10 scale-[1.01]'
                  : 'border-slate-700/80 hover:border-slate-500 bg-slate-800/40 hover:bg-slate-800/60'
              }`}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={(e) => e.target.files?.[0] && processFile(e.target.files[0])}
                accept="image/*,.pdf,.txt,.csv,.doc,.docx"
                className="hidden"
              />

              <div className="flex flex-col items-center justify-center space-y-2.5">
                <div className="w-10 h-10 rounded-full bg-indigo-500/20 text-indigo-300 flex items-center justify-center">
                  {isProcessing ? (
                    <RefreshCw className="w-5 h-5 animate-spin text-indigo-400" />
                  ) : (
                    <Upload className="w-5 h-5 text-indigo-400" />
                  )}
                </div>

                <div>
                  <p className="text-xs sm:text-sm font-semibold text-slate-200">
                    {isProcessing
                      ? 'Analyzing timetable with Gemini 3.8...'
                      : 'Click to upload or drag & drop your Exam Timetable'}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Supports Notice board photos, PDF timetables, or exported schedules (JPG, PNG, PDF, TXT)
                  </p>
                </div>

                <div className="flex items-center gap-3 text-[11px] text-slate-400 pt-0.5">
                  <span className="flex items-center gap-1">
                    <FileImage className="w-3 h-3 text-slate-500" /> Photos
                  </span>
                  <span className="flex items-center gap-1">
                    <FileText className="w-3 h-3 text-slate-500" /> PDFs
                  </span>
                  <span className="flex items-center gap-1 text-indigo-300 font-semibold">
                    <Sparkles className="w-3 h-3 text-indigo-400" /> Auto-Extraction
                  </span>
                </div>
              </div>
            </div>

            {/* Upload Status Banner */}
            {uploadStatus && (
              <div
                className={`mt-3 p-3 rounded-xl flex items-center gap-3 text-xs font-medium ${
                  uploadStatus.type === 'success'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : uploadStatus.type === 'error'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                }`}
              >
                {uploadStatus.type === 'success' && <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />}
                {uploadStatus.type === 'error' && <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />}
                {uploadStatus.type === 'info' && <Sparkles className="w-4 h-4 shrink-0 text-indigo-400 animate-spin" />}
                <span>{uploadStatus.message}</span>
              </div>
            )}
          </div>

          {/* Right: Knowledge Graduation Ladder Visual (5 cols) */}
          <div className="lg:col-span-5 relative min-h-[260px] bg-slate-950 border-t lg:border-t-0 lg:border-l border-slate-800 overflow-hidden group flex flex-col justify-end">
            <img
              src={gradLightbulbLadderImg}
              alt="Ladder to Graduation"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 opacity-80"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent" />

            <div className="relative z-10 p-5 space-y-1.5">
              <span className="inline-block px-2 py-0.5 rounded bg-amber-400 text-slate-950 text-[10px] font-black uppercase tracking-wider shadow">
                Graduation Milestone
              </span>
              <h3 className="text-base font-bold text-white drop-shadow">
                Every Exam Step Leads to the Top
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed drop-shadow">
                Uploading your exam dates sets up automated countdown timers and locks down social media
                distractions during high-yield revision windows.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Manual Exam Add Form Modal/Accordion */}
      {showAddForm && (
        <form
          onSubmit={handleManualAdd}
          className="bg-slate-900 border border-slate-700/80 rounded-2xl p-5 space-y-4 shadow-lg animate-fadeIn"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-indigo-400" />
              Add Custom Exam to Timetable
            </h3>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="text-slate-400 hover:text-white text-xs"
            >
              Cancel
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs text-slate-300 font-medium mb-1">Subject Name *</label>
              <input
                type="text"
                required
                value={newSubject}
                onChange={(e) => setNewSubject(e.target.value)}
                placeholder="e.g. Molecular Biology or Discrete Math"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-300 font-medium mb-1">Course / Subject Code</label>
              <input
                type="text"
                value={newCode}
                onChange={(e) => setNewCode(e.target.value)}
                placeholder="e.g. BIO-204"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-300 font-medium mb-1">Exam Date *</label>
              <input
                type="date"
                required
                value={newDate}
                onChange={(e) => setNewDate(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-300 font-medium mb-1">
              Syllabus Topics (comma separated)
            </label>
            <input
              type="text"
              value={newTopics}
              onChange={(e) => setNewTopics(e.target.value)}
              placeholder="e.g. DNA Replication, Transcription, Enzyme Kinetics, Genetic Code"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-300 font-medium">Priority:</span>
              {(['High', 'Medium', 'Low'] as const).map((p) => (
                <button
                  type="button"
                  key={p}
                  onClick={() => setNewPriority(p)}
                  className={`px-2.5 py-1 rounded text-xs font-semibold transition-all ${
                    newPriority === p
                      ? p === 'High'
                        ? 'bg-rose-500 text-white'
                        : p === 'Medium'
                        ? 'bg-amber-500 text-white'
                        : 'bg-emerald-500 text-white'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>

            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg transition-all"
            >
              Save to Timetable
            </button>
          </div>
        </form>
      )}

      {/* Active Exam Schedule Cards */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-indigo-400" />
            Scheduled Exams ({exams.length})
            <span className="text-xs text-slate-400 font-normal">
              — apps locked until exams conclude
            </span>
          </h3>
          <span className="text-xs text-slate-400">
            Discipline: <strong className="text-indigo-300">{currentField}</strong>
          </span>
        </div>

        {exams.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400">
            <Calendar className="w-8 h-8 mx-auto text-slate-600 mb-2" />
            <p className="text-sm font-medium">No exams scheduled yet.</p>
            <p className="text-xs text-slate-500 mt-1">
              Upload your timetable above or click "Load Preset" to populate your exam schedule.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {exams.map((exam) => {
              const countdown = calculateDaysRemaining(exam.date);
              const isUrgent = countdown.includes('Tomorrow') || countdown.includes('Today') || countdown.includes('In 1') || countdown.includes('In 2');

              return (
                <div
                  key={exam.id}
                  className={`bg-slate-900 border rounded-xl p-4 transition-all hover:border-slate-700 relative overflow-hidden flex flex-col justify-between ${
                    isUrgent ? 'border-amber-500/40 shadow-lg shadow-amber-500/5' : 'border-slate-800'
                  }`}
                >
                  <div>
                    {/* Header: code, countdown, priority */}
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-mono font-bold bg-slate-800 text-indigo-300 px-2 py-0.5 rounded border border-slate-700">
                          {exam.code || 'EXAM'}
                        </span>
                        <span
                          className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                            exam.priority === 'High'
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                              : exam.priority === 'Medium'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          }`}
                        >
                          {exam.priority} Priority
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <span
                          className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                            isUrgent
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30 animate-pulse'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {countdown}
                        </span>

                        <button
                          onClick={() => handleDeleteExam(exam.id)}
                          title="Remove exam"
                          className="text-slate-500 hover:text-rose-400 p-1 rounded transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Subject Title */}
                    <h4 className="text-base font-bold text-white tracking-tight mb-1.5">
                      {exam.subject}
                    </h4>

                    {/* Meta info: Date, Time */}
                    <div className="flex items-center gap-4 text-xs text-slate-400 mb-3">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-500" />
                        {exam.date}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-slate-500" />
                        {exam.time}
                      </span>
                    </div>

                    {/* Syllabus topics pills */}
                    <div className="mb-4">
                      <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                        <BookOpen className="w-3 h-3 text-indigo-400" /> Syllabus Topics:
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {exam.syllabusTopics.map((topic, i) => (
                          <button
                            key={i}
                            onClick={() => onSelectExamForStudy(exam, topic)}
                            disabled={isQuizActive}
                            title="Click to study this topic with AI Tutor"
                            className="text-[11px] bg-slate-800/90 hover:bg-indigo-900/40 text-slate-300 hover:text-indigo-200 px-2 py-0.5 rounded-md border border-slate-700/80 transition-colors text-left"
                          >
                            • {topic}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Actions: Study topic or Launch Quiz */}
                  <div className="pt-3 border-t border-slate-800/80 flex items-center gap-2">
                    <button
                      onClick={() => onSelectExamForStudy(exam)}
                      disabled={isQuizActive}
                      className="flex-1 py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-semibold border border-slate-700 transition-all flex items-center justify-center gap-1.5 disabled:opacity-40"
                    >
                      <span>Ask AI Tutor</span>
                    </button>

                    <button
                      onClick={() => onSelectExamForQuiz(exam)}
                      className="flex-1 py-1.5 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <span>Take Quiz & Earn</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
